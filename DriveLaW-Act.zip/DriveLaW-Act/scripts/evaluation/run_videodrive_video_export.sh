set -x
set -e

export NUPLAN_MAP_VERSION="nuplan-maps-v1.0"
export NUPLAN_MAPS_ROOT="/home/ma-user/work2/shuzhengwang/dataset/NAVSIM/dataset/maps"
export NAVSIM_EXP_ROOT="/cache/shuzhengwang/project/drivelaw/exp"
export NAVSIM_DEVKIT_ROOT="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/DriveLaW-Act"
export OPENSCENE_DATA_ROOT="/home/ma-user/work2/shuzhengwang/dataset/NAVSIM/dataset"
export PYTHONPATH="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/DriveLaW-Act:$PYTHONPATH"

export NCCL_DEBUG=WARN
export NCCL_IB_DISABLE=0
export NCCL_P2P_DISABLE=1
export NCCL_SHM_DISABLE=0
export TORCH_NCCL_ENABLE_MONITORING=0
export NCCL_TIMEOUT=36000
export TORCH_DISTRIBUTED_TIMEOUT_SECONDS=36000

export CUDA_VISIBLE_DEVICES=3

NPROC_PER_NODE=1
MASTER_PORT=61995
VIDEO_NUM_INFERENCE_STEPS=30
MAX_SCENARIOS=20
VIDEO_OUTPUT_DIR="/cache/shuzhengwang/project/drivelaw/video_export"
VIDEO_FPS=5
VLM_PATH="/path/to/qwen3.5_checkpoint"
VLM_CACHE_STRATEGY="direct_forward"

torchrun --nproc_per_node=$NPROC_PER_NODE \
         --nnodes=1 \
         --node_rank=0 \
         --rdzv_endpoint=127.0.0.1:$MASTER_PORT \
    $NAVSIM_DEVKIT_ROOT/navsim/planning/script/run_videodrive_video_export.py \
    agent=videodrive_agent \
    train_test_split=navtest \
    experiment_name=video_export/videodrive_agent \
    video_export.num_inference_steps=$VIDEO_NUM_INFERENCE_STEPS \
    video_export.max_scenarios=$MAX_SCENARIOS \
    video_export.output_dir=$VIDEO_OUTPUT_DIR \
    video_export.fps=$VIDEO_FPS \
    agent.vlm_path=$VLM_PATH \
    agent.vlm_cache_strategy=$VLM_CACHE_STRATEGY
