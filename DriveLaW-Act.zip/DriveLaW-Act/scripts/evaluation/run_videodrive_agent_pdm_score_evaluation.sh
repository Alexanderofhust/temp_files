set -x
TRAIN_TEST_SPLIT=navtest
export NUPLAN_MAP_VERSION="nuplan-maps-v1.0"
export NUPLAN_MAPS_ROOT="/home/ma-user/work2/shuzhengwang/dataset/NAVSIM/dataset/maps"
export NAVSIM_EXP_ROOT="/cache/shuzhengwang/project/drivelaw/exp"
export NAVSIM_DEVKIT_ROOT="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/DriveLaW-Act"
export OPENSCENE_DATA_ROOT="/home/ma-user/work2/shuzhengwang/dataset/NAVSIM/dataset"

export CUDA_VISIBLE_DEVICES=3
# Ensure navsim package is importable (fixes "Error locating target VideoDriveAgent")
export PYTHONPATH="${NAVSIM_DEVKIT_ROOT}:${PYTHONPATH}"
export NCCL_DEBUG=WARN
export NCCL_IB_DISABLE=0
export NCCL_P2P_DISABLE=1
export NCCL_SHM_DISABLE=0
export NCCL_TIMEOUT=1800000

# In joint_vlm_enable=True mode, action_vlm_compress_tokens/action_vlm_num_queries
# must match the training run because they change the joint VLM resampler shape.

torchrun --nproc_per_node=1 \
         --nnodes=1 \
         --node_rank=0 \
         --rdzv_endpoint=127.0.0.1:61993 \
    $NAVSIM_DEVKIT_ROOT/navsim/planning/script/run_pdm_score_videodrive.py \
    train_test_split=$TRAIN_TEST_SPLIT \
    agent=videodrive_agent \
    agent.config_file="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/DriveLaW-Act/navsim/agents/videodrive/configs/ltx_model/video_model_infer_navsim_eval.yaml" \
    cache_path="" \
    use_cache_without_dataset=False \
    experiment_name=eval/videodrive_agent_eval_add_hidden_states_cross_attention_no_video_latent_ablation_batchsize_64_35k \
    agent.use_recogdrive_vlm_condition=True \
    agent.recogdrive_vlm_mode="online" \
    agent.vlm_path="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/recogdrive/pretrained_models/recogdrive/base-2B/ReCogDrive-Base-VLM" \
    agent.vlm_type="internvl" \
    agent.vlm_size="small" \
    agent.action_vlm_enable=True \
    agent.action_vlm_hidden_dim=1536 \
    agent.action_vlm_compress_tokens=true \
    agent.action_vlm_num_queries=128 \
    agent.action_vlm_context_dim=512 \
    agent.action_vlm_adapter_mode=video_conditioned \
    agent.action_vlm_block_start=22 \
    agent.action_vlm_video_pool_tokens=64 \
    agent.action_history_input=true \
    agent.joint_vlm_enable=True \
    agent.joint_video_attend_vlm=false
