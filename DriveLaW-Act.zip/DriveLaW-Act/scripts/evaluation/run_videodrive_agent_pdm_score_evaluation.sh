set -x
set -e

export NUPLAN_MAP_VERSION="nuplan-maps-v1.0"
export NUPLAN_MAPS_ROOT="/home/ma-user/work2/shuzhengwang/dataset/NAVSIM/dataset/maps"
export NAVSIM_EXP_ROOT="/cache/shuzhengwang/project/drivelaw/exp"
export NAVSIM_DEVKIT_ROOT="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/DriveLaW-Act"
export OPENSCENE_DATA_ROOT="/home/ma-user/work2/shuzhengwang/dataset/NAVSIM/dataset"
export CUDA_VISIBLE_DEVICES=3
# Ensure navsim package is importable (fixes "Error locating target VideoDriveAgent")
export PYTHONPATH="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/DriveLaW-Act:$PYTHONPATH"
export NCCL_DEBUG=WARN
export NCCL_IB_DISABLE=0
export NCCL_P2P_DISABLE=1
export NCCL_SHM_DISABLE=0
export TORCH_NCCL_ENABLE_MONITORING=0
export NCCL_TIMEOUT=36000
export TORCH_DISTRIBUTED_TIMEOUT_SECONDS=36000

torchrun --nproc_per_node=1 \
         --nnodes=1 \
         --node_rank=0 \
         --rdzv_endpoint=127.0.0.1:61993 \
    $NAVSIM_DEVKIT_ROOT/navsim/planning/script/run_pdm_score_videodrive.py \
    agent=videodrive_agent \
    agent.config_file="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/DriveLaW-Act/navsim/agents/videodrive/configs/ltx_model/video_model_infer_navsim_eval.yaml" \
    experiment_name=eval/videodrive_agent_eval_add_hidden_states_cross_attention_no_video_latent_ablation_batchsize_64_35k \
    train_test_split=navtest \
    metric_cache_path="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/exp_data/metric_cache"
