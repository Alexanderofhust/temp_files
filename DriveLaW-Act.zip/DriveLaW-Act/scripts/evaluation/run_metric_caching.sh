set -e

TRAIN_TEST_SPLIT=${TRAIN_TEST_SPLIT:-navtest}
export NUPLAN_MAP_VERSION="${NUPLAN_MAP_VERSION:-nuplan-maps-v1.0}"
export NUPLAN_MAPS_ROOT="${NUPLAN_MAPS_ROOT:-/home/ma-user/work2/shuzhengwang/dataset/NAVSIM/dataset/maps}"
export NAVSIM_EXP_ROOT="${NAVSIM_EXP_ROOT:-/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/exp_data}"
export NAVSIM_DEVKIT_ROOT="${NAVSIM_DEVKIT_ROOT:-/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/DriveLaW-Act}"
export OPENSCENE_DATA_ROOT="${OPENSCENE_DATA_ROOT:-/home/ma-user/work2/shuzhengwang/dataset/NAVSIM/dataset}"
METRIC_CACHE_ROOT=${METRIC_CACHE_ROOT:-$NAVSIM_EXP_ROOT}

if [ "$TRAIN_TEST_SPLIT" = "navtest" ]; then
    DEFAULT_CACHE_PATH="$METRIC_CACHE_ROOT/metric_cache"
else
    DEFAULT_CACHE_PATH="$METRIC_CACHE_ROOT/metric_cache_${TRAIN_TEST_SPLIT}"
fi
CACHE_PATH=${CACHE_PATH:-$DEFAULT_CACHE_PATH}
NPROC_PER_NODE=${NPROC_PER_NODE:-1}
RDZV_ENDPOINT=${RDZV_ENDPOINT:-127.0.0.1:63165}

export PYTHONPATH="${NAVSIM_DEVKIT_ROOT}:${PYTHONPATH:-}"
export NCCL_DEBUG=WARN
export NCCL_IB_DISABLE=0
export NCCL_P2P_DISABLE=1
export NCCL_SHM_DISABLE=0
export NCCL_TIMEOUT=1800000

echo "Caching metric data for split: $TRAIN_TEST_SPLIT"
echo "Metric cache path: $CACHE_PATH"

torchrun --nproc_per_node=$NPROC_PER_NODE \
         --nnodes=1 \
         --node_rank=0 \
         --rdzv_endpoint=$RDZV_ENDPOINT \
    $NAVSIM_DEVKIT_ROOT/navsim/planning/script/run_metric_caching.py \
    train_test_split=$TRAIN_TEST_SPLIT \
    cache.cache_path="$CACHE_PATH"
