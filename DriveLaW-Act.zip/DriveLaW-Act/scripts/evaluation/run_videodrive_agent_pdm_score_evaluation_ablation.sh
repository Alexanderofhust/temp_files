#!/usr/bin/env bash
set -x
set -e

export NUPLAN_MAP_VERSION="nuplan-maps-v1.0"
export NUPLAN_MAPS_ROOT="/home/ma-user/work2/shuzhengwang/dataset/NAVSIM/dataset/maps"
export NAVSIM_EXP_ROOT="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/exp_data/exp"
export NAVSIM_DEVKIT_ROOT="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/DriveLaW-Act"
export OPENSCENE_DATA_ROOT="/home/ma-user/work2/shuzhengwang/dataset/NAVSIM/dataset"
export CUDA_VISIBLE_DEVICES=3
export PYTHONPATH="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/DriveLaW-Act:$PYTHONPATH"

export NCCL_DEBUG=WARN
export NCCL_IB_DISABLE=0
export NCCL_P2P_DISABLE=1
export NCCL_SHM_DISABLE=0
export TORCH_NCCL_ENABLE_MONITORING=0
export NCCL_TIMEOUT=36000
export TORCH_DISTRIBUTED_TIMEOUT_SECONDS=36000

CONFIG_FILE="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/DriveLaW-Act/navsim/agents/videodrive/configs/ltx_model/video_model_infer_navsim_eval_ablation.yaml"
METRIC_CACHE_PATH="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/exp_data/exp/metric_cache_navtest_1000"
SCRIPT_PATH="$NAVSIM_DEVKIT_ROOT/navsim/planning/script/run_pdm_score_videodrive_ablation.py"

run_eval() {
    local VLM_ABLATION=$1
    local VIDEO_ABLATION=$2

    local EXP_NAME="eval/videodrive_agent_eval_ablation_vlm_${VLM_ABLATION}_video_${VIDEO_ABLATION}"

    echo "============================================================"
    echo "Running ablation:"
    echo "  VLM hidden ablation    = ${VLM_ABLATION}"
    echo "  Video context ablation = ${VIDEO_ABLATION}"
    echo "  Experiment name        = ${EXP_NAME}"
    echo "============================================================"

    torchrun --nproc_per_node=1 \
             --nnodes=1 \
             --node_rank=0 \
             --rdzv_endpoint=127.0.0.1:61993 \
        "$SCRIPT_PATH" \
        agent=videodrive_ablation_agent \
        agent.config_file="$CONFIG_FILE" \
        experiment_name="$EXP_NAME" \
        train_test_split=navtest_1000 \
        metric_cache_path="$METRIC_CACHE_PATH" \
        agent.vlm_hidden_ablation="${VLM_ABLATION}" \
        agent.video_context_ablation="${VIDEO_ABLATION}" \
        agent.ablation_noise_seed=42 \
        agent.ablation_noise_scale=1.0
}

# 1. 原始设置：VLM 和 Video 都不消融
run_eval none none

# 2. VLM token 置零，Video 正常
run_eval zero none

# 3. VLM token 加噪声，Video 正常
run_eval noise none

# 4. VLM 正常，Video token 置零
run_eval none zero

# 5. VLM 正常，Video token 加噪声
run_eval none noise