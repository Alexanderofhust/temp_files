export NUPLAN_MAP_VERSION="nuplan-maps-v1.0"
export NUPLAN_MAPS_ROOT="/home/ma-user/work2/shuzhengwang/dataset/NAVSIM/dataset/maps"
export NAVSIM_EXP_ROOT="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/exp_data/exp"
export NAVSIM_DEVKIT_ROOT="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/DriveLaW-Act"
export OPENSCENE_DATA_ROOT="/home/ma-user/work2/shuzhengwang/dataset/NAVSIM/dataset"

export NCCL_DEBUG=WARN
export NCCL_IB_DISABLE=0
export NCCL_P2P_DISABLE=1
export NCCL_SHM_DISABLE=0
export TORCH_NCCL_ENABLE_MONITORING=0
export NCCL_TIMEOUT=36000
export TORCH_DISTRIBUTED_TIMEOUT_SECONDS=36000

export CUDA_VISIBLE_DEVICES=4,5,6,7

VLM_COMPRESS_TOKENS=false
VLM_NUM_QUERIES=64
PDM_EVAL_ENABLED=true
PDM_EVAL_VLM_PATH="/path/to/qwen3.5_checkpoint"
PDM_EVAL_VLM_CACHE_STRATEGY=direct_forward

torchrun --nproc_per_node=4 \
         --nnodes=1 \
         --node_rank=0 \
         --rdzv_endpoint=127.0.0.1:61181 \
    $NAVSIM_DEVKIT_ROOT/navsim/agents/videodrive/run_training_videodrive.py \
    agent=videodrive_agent \
    agent.config_file="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/DriveLaW-Act/navsim/agents/videodrive/configs/ltx_model/video_model_infer_navsim.yaml" \
    experiment_name=training_video_agent_masked_joint_attention_video_can_attend_vlm_no_vlm_compress_batchsize_8 \
    train_test_split=navtrain \
    report_to=tensorboard \
    resume_training=false \
    resume_checkpoint_path="" \
    agent.vlm_compress_tokens=$VLM_COMPRESS_TOKENS \
    agent.vlm_num_queries=$VLM_NUM_QUERIES \
    pdm_eval.enabled=$PDM_EVAL_ENABLED \
    pdm_eval.vlm_path=$PDM_EVAL_VLM_PATH \
    pdm_eval.vlm_cache_strategy=$PDM_EVAL_VLM_CACHE_STRATEGY
