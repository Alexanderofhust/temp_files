export NUPLAN_MAP_VERSION="nuplan-maps-v1.0"
export NUPLAN_MAPS_ROOT="/home/ma-user/work2/shuzhengwang/dataset/NAVSIM/dataset/maps"
export NAVSIM_EXP_ROOT="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/exp_data/exp"
export NAVSIM_DEVKIT_ROOT="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/DriveLaW-Act"
export OPENSCENE_DATA_ROOT="/home/ma-user/work2/shuzhengwang/dataset/NAVSIM/dataset"
TRAIN_TEST_SPLIT=navtrain
export NCCL_DEBUG=WARN
export NCCL_IB_DISABLE=0
export NCCL_P2P_DISABLE=1
export NCCL_SHM_DISABLE=0
export NCCL_TIMEOUT=1800000

export CUDA_VISIBLE_DEVICES=4,5,6,7

# In joint_vlm_enable=True mode, action_vlm_compress_tokens/action_vlm_num_queries
# control the learnable-query VLM resampler used before masked joint attention.

torchrun --nproc_per_node=4 \
         --nnodes=1 \
         --node_rank=0 \
         --rdzv_endpoint=127.0.0.1:61181 \
    $NAVSIM_DEVKIT_ROOT/navsim/agents/videodrive/run_training_videodrive.py \
    agent=videodrive_agent \
    agent.config_file="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/DriveLaW-Act/navsim/agents/videodrive/configs/ltx_model/video_model_infer_navsim.yaml" \
    experiment_name=training_video_agent_masked_joint_attention_video_can_attend_vlm_no_vlm_compress_batchsize_8 \
    train_test_split=$TRAIN_TEST_SPLIT \
    cache_path='/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/exp_data/exp/videodrive_agent_cache_dir_final_front_navsim' \
    recogdrive_cache_path='/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/exp_data/exp/recogdrive_agent_cache_dir_2B_navsim_pretrain_pdms_84.39' \
    use_recogdrive_vlm_condition=true \
    agent.action_vlm_hidden_dim=1536 \
    agent.action_vlm_compress_tokens=false \
    agent.action_vlm_num_queries=128 \
    agent.action_vlm_context_dim=512 \
    agent.action_vlm_adapter_mode=video_conditioned \
    agent.action_vlm_block_start=0 \
    agent.action_vlm_video_pool_tokens=512 \
    agent.action_history_input=true \
    use_cache_without_dataset=false \
    agent.action_vlm_enable=true \
    agent.joint_vlm_enable=true \
    agent.joint_video_attend_vlm=true
