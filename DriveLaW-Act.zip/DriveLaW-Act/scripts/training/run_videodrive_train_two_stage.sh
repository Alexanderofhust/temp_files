set -euo pipefail

export NUPLAN_MAP_VERSION="nuplan-maps-v1.0"
export NUPLAN_MAPS_ROOT="/home/ma-user/work2/shuzhengwang/dataset/NAVSIM/dataset/maps"
export NAVSIM_EXP_ROOT="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/exp_data/exp"
export NAVSIM_DEVKIT_ROOT="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/DriveLaW-Act"
export OPENSCENE_DATA_ROOT="/home/ma-user/work2/shuzhengwang/dataset/NAVSIM/dataset"

export NCCL_DEBUG=WARN
export NCCL_IB_DISABLE=0
export NCCL_P2P_DISABLE=1
export NCCL_SHM_DISABLE=0
export TORCH_NCCL_ENABLE_MONITORING=0
export NCCL_TIMEOUT=36000
export TORCH_DISTRIBUTED_TIMEOUT_SECONDS=36000

export CUDA_VISIBLE_DEVICES=4,5,6,7

NUM_GPUS=4
NUM_NODES=1
NODE_RANK=0
MASTER_ADDR=127.0.0.1
MASTER_PORT_STAGE1=61181
MASTER_PORT_STAGE2=61182

CONFIG_FILE="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/DriveLaW-Act/navsim/agents/videodrive/configs/ltx_model/video_model_two_stage_train_navsim.yaml"
TWO_STAGE_ROOT="/cache/shuzhengwang/project/drivelaw/two_stage_train"
ORIGINAL_VIDEO_MODEL_PATH="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/DriveLaW/DriveLaW-Video/transformer/diffusion_pytorch_model.safetensors"

TRAIN_TEST_SPLIT=navtrain
REPORT_TO=tensorboard
RETURN_ACTION=true
RETURN_VIDEO=false
JOINT_VLM_ENABLE=true
CROSS_ATTENTION_VLM_ENABLE=false
VLM_COMPRESS_TOKENS=false
VLM_NUM_QUERIES=64
VLM_PROFILE=qwen3_5
VLM_HIDDEN_STATE_KEY=last_hidden_state
VLM_HIDDEN_DIM=2048

PDM_EVAL_ENABLED=true
if [ "$VLM_PROFILE" = "internvl3" ]; then
  VLM_CACHE_PATH="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/exp_data/exp/recogdrive_agent_cache_dir_train"
  VLM_FEATURE_NAME=internvl_feature
  PDM_EVAL_VLM_PATH="/path/to/ReCogDrive_2b_or_internvl3_checkpoint"
  PDM_EVAL_VLM_CACHE_STRATEGY=direct_forward
  PDM_EVAL_VLM_SYSTEM_PROMPT=""
elif [ "$VLM_PROFILE" = "cosmos_reason" ]; then
  VLM_CACHE_PATH="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/exp_data/exp/cosmos_reason2-2B_coc_reforward_hidden_states_cache_data"
  VLM_FEATURE_NAME=cosmos_reason_feature
  PDM_EVAL_VLM_PATH="/home/ma-user/work2/shuzhengwang/projects/VLA-World-model/drivelaw-main/cosmos-reason2/Cosmos-Reason2-2B"
  PDM_EVAL_VLM_CACHE_STRATEGY=coc_reforward
  PDM_EVAL_VLM_SYSTEM_PROMPT="You are a specialized agent for visual scene understanding in autonomous driving. Analyze the provided front-view image and ego-motion context to infer the ego vehicle's driving behavior. Follow the driving-decision rules in the user prompt. Output one concise factual sentence only."
elif [ "$VLM_PROFILE" = "qwen3_5" ]; then
  VLM_CACHE_PATH="/path/to/qwen3_5_hidden_state_cache_dir_navtrain"
  VLM_FEATURE_NAME=internvl_feature
  PDM_EVAL_VLM_PATH="/path/to/qwen3.5_checkpoint"
  PDM_EVAL_VLM_CACHE_STRATEGY=direct_forward
  PDM_EVAL_VLM_SYSTEM_PROMPT="You are a helpful autonomous driving assistant."
else
  echo "Unsupported VLM_PROFILE: $VLM_PROFILE" >&2
  exit 1
fi

STAGE1_EXPERIMENT_NAME=videodrive_two_stage_stage1_action_only_freeze_video
STAGE1_SAVE_FOLDER="$TWO_STAGE_ROOT/stage1_action_only_freeze_video"
STAGE1_DIFFUSION_MODEL_PATH="$ORIGINAL_VIDEO_MODEL_PATH"
STAGE1_TRAIN_MODE=action_vlm_no_video
STAGE1_BATCH_SIZE=2
STAGE1_LR=0.00003
STAGE1_TRAIN_STEPS=20000
STAGE1_TRAIN_EPOCHS=100
STAGE1_STEPS_TO_SAVE=5000
STAGE1_STEPS_TO_LOG=20
STAGE1_LR_WARMUP_STEPS=1000
STAGE1_GRADIENT_ACCUMULATION_STEPS=1
STAGE1_JOINT_VIDEO_ATTEND_VLM=false
STAGE1_FINAL_MODEL="$STAGE1_SAVE_FOLDER/step_${STAGE1_TRAIN_STEPS}/diffusion_pytorch_model.safetensors"

STAGE2_EXPERIMENT_NAME=videodrive_two_stage_stage2_action_full_video_attend_vlm
STAGE2_SAVE_FOLDER="$TWO_STAGE_ROOT/stage2_action_full_video_attend_vlm"
STAGE2_DIFFUSION_MODEL_PATH="$STAGE1_FINAL_MODEL"
STAGE2_TRAIN_MODE=action_full
STAGE2_BATCH_SIZE=2
STAGE2_LR=0.00001
STAGE2_TRAIN_STEPS=80000
STAGE2_TRAIN_EPOCHS=100
STAGE2_STEPS_TO_SAVE=5000
STAGE2_STEPS_TO_LOG=20
STAGE2_LR_WARMUP_STEPS=1000
STAGE2_GRADIENT_ACCUMULATION_STEPS=1
STAGE2_JOINT_VIDEO_ATTEND_VLM=true

mkdir -p "$STAGE1_SAVE_FOLDER" "$STAGE2_SAVE_FOLDER"

torchrun --nproc_per_node=$NUM_GPUS \
         --nnodes=$NUM_NODES \
         --node_rank=$NODE_RANK \
         --rdzv_endpoint=$MASTER_ADDR:$MASTER_PORT_STAGE1 \
    $NAVSIM_DEVKIT_ROOT/navsim/agents/videodrive/run_training_videodrive_two_stage.py \
    agent=videodrive_two_stage_agent \
    agent.config_file="$CONFIG_FILE" \
    agent.diffusion_model_path="$STAGE1_DIFFUSION_MODEL_PATH" \
    experiment_name=$STAGE1_EXPERIMENT_NAME \
    train_test_split=$TRAIN_TEST_SPLIT \
    output_dir="$STAGE1_SAVE_FOLDER" \
    use_vlm_condition=true \
    vlm_cache_path="$VLM_CACHE_PATH" \
    vlm_profile=$VLM_PROFILE \
    vlm_feature_name=$VLM_FEATURE_NAME \
    vlm_hidden_state_key=$VLM_HIDDEN_STATE_KEY \
    report_to=$REPORT_TO \
    resume_training=false \
    resume_checkpoint_path="" \
    two_stage.stage_name=stage1 \
    two_stage.save_folder="$STAGE1_SAVE_FOLDER" \
    two_stage.diffusion_model_path="$STAGE1_DIFFUSION_MODEL_PATH" \
    two_stage.train_mode=$STAGE1_TRAIN_MODE \
    two_stage.batch_size=$STAGE1_BATCH_SIZE \
    two_stage.lr=$STAGE1_LR \
    two_stage.train_steps=$STAGE1_TRAIN_STEPS \
    two_stage.train_epochs=$STAGE1_TRAIN_EPOCHS \
    two_stage.steps_to_save=$STAGE1_STEPS_TO_SAVE \
    two_stage.steps_to_log=$STAGE1_STEPS_TO_LOG \
    two_stage.lr_warmup_steps=$STAGE1_LR_WARMUP_STEPS \
    two_stage.gradient_accumulation_steps=$STAGE1_GRADIENT_ACCUMULATION_STEPS \
    two_stage.return_action=$RETURN_ACTION \
    two_stage.return_video=$RETURN_VIDEO \
    two_stage.use_vlm_condition=true \
    two_stage.vlm_cache_path="$VLM_CACHE_PATH" \
    two_stage.vlm_profile=$VLM_PROFILE \
    two_stage.vlm_feature_name=$VLM_FEATURE_NAME \
    two_stage.vlm_hidden_state_key=$VLM_HIDDEN_STATE_KEY \
    two_stage.vlm_hidden_dim=$VLM_HIDDEN_DIM \
    two_stage.joint_vlm_enable=$JOINT_VLM_ENABLE \
    two_stage.joint_video_attend_vlm=$STAGE1_JOINT_VIDEO_ATTEND_VLM \
    two_stage.cross_attention_vlm_enable=$CROSS_ATTENTION_VLM_ENABLE \
    two_stage.vlm_compress_tokens=$VLM_COMPRESS_TOKENS \
    two_stage.vlm_num_queries=$VLM_NUM_QUERIES \
    agent.joint_vlm_enable=$JOINT_VLM_ENABLE \
    agent.vlm_profile=$VLM_PROFILE \
    agent.vlm_hidden_dim=$VLM_HIDDEN_DIM \
    agent.vlm_feature_name=$VLM_FEATURE_NAME \
    agent.vlm_hidden_state_key=$VLM_HIDDEN_STATE_KEY \
    agent.joint_video_attend_vlm=$STAGE1_JOINT_VIDEO_ATTEND_VLM \
    agent.cross_attention_vlm_enable=$CROSS_ATTENTION_VLM_ENABLE \
    agent.vlm_compress_tokens=$VLM_COMPRESS_TOKENS \
    agent.vlm_num_queries=$VLM_NUM_QUERIES \
    pdm_eval.enabled=$PDM_EVAL_ENABLED \
    pdm_eval.vlm_path=$PDM_EVAL_VLM_PATH \
    pdm_eval.vlm_profile=$VLM_PROFILE \
    pdm_eval.vlm_system_prompt="$PDM_EVAL_VLM_SYSTEM_PROMPT" \
    pdm_eval.vlm_cache_strategy=$PDM_EVAL_VLM_CACHE_STRATEGY

if [ ! -f "$STAGE1_FINAL_MODEL" ]; then
  echo "Stage 1 finished, but expected checkpoint was not found: $STAGE1_FINAL_MODEL" >&2
  exit 1
fi

torchrun --nproc_per_node=$NUM_GPUS \
         --nnodes=$NUM_NODES \
         --node_rank=$NODE_RANK \
         --rdzv_endpoint=$MASTER_ADDR:$MASTER_PORT_STAGE2 \
    $NAVSIM_DEVKIT_ROOT/navsim/agents/videodrive/run_training_videodrive_two_stage.py \
    agent=videodrive_two_stage_agent \
    agent.config_file="$CONFIG_FILE" \
    agent.diffusion_model_path="$STAGE2_DIFFUSION_MODEL_PATH" \
    experiment_name=$STAGE2_EXPERIMENT_NAME \
    train_test_split=$TRAIN_TEST_SPLIT \
    output_dir="$STAGE2_SAVE_FOLDER" \
    use_vlm_condition=true \
    vlm_cache_path="$VLM_CACHE_PATH" \
    vlm_profile=$VLM_PROFILE \
    vlm_feature_name=$VLM_FEATURE_NAME \
    vlm_hidden_state_key=$VLM_HIDDEN_STATE_KEY \
    report_to=$REPORT_TO \
    resume_training=false \
    resume_checkpoint_path="" \
    two_stage.stage_name=stage2 \
    two_stage.save_folder="$STAGE2_SAVE_FOLDER" \
    two_stage.diffusion_model_path="$STAGE2_DIFFUSION_MODEL_PATH" \
    two_stage.train_mode=$STAGE2_TRAIN_MODE \
    two_stage.batch_size=$STAGE2_BATCH_SIZE \
    two_stage.lr=$STAGE2_LR \
    two_stage.train_steps=$STAGE2_TRAIN_STEPS \
    two_stage.train_epochs=$STAGE2_TRAIN_EPOCHS \
    two_stage.steps_to_save=$STAGE2_STEPS_TO_SAVE \
    two_stage.steps_to_log=$STAGE2_STEPS_TO_LOG \
    two_stage.lr_warmup_steps=$STAGE2_LR_WARMUP_STEPS \
    two_stage.gradient_accumulation_steps=$STAGE2_GRADIENT_ACCUMULATION_STEPS \
    two_stage.return_action=$RETURN_ACTION \
    two_stage.return_video=$RETURN_VIDEO \
    two_stage.use_vlm_condition=true \
    two_stage.vlm_cache_path="$VLM_CACHE_PATH" \
    two_stage.vlm_profile=$VLM_PROFILE \
    two_stage.vlm_feature_name=$VLM_FEATURE_NAME \
    two_stage.vlm_hidden_state_key=$VLM_HIDDEN_STATE_KEY \
    two_stage.vlm_hidden_dim=$VLM_HIDDEN_DIM \
    two_stage.joint_vlm_enable=$JOINT_VLM_ENABLE \
    two_stage.joint_video_attend_vlm=$STAGE2_JOINT_VIDEO_ATTEND_VLM \
    two_stage.cross_attention_vlm_enable=$CROSS_ATTENTION_VLM_ENABLE \
    two_stage.vlm_compress_tokens=$VLM_COMPRESS_TOKENS \
    two_stage.vlm_num_queries=$VLM_NUM_QUERIES \
    agent.joint_vlm_enable=$JOINT_VLM_ENABLE \
    agent.vlm_profile=$VLM_PROFILE \
    agent.vlm_hidden_dim=$VLM_HIDDEN_DIM \
    agent.vlm_feature_name=$VLM_FEATURE_NAME \
    agent.vlm_hidden_state_key=$VLM_HIDDEN_STATE_KEY \
    agent.joint_video_attend_vlm=$STAGE2_JOINT_VIDEO_ATTEND_VLM \
    agent.cross_attention_vlm_enable=$CROSS_ATTENTION_VLM_ENABLE \
    agent.vlm_compress_tokens=$VLM_COMPRESS_TOKENS \
    agent.vlm_num_queries=$VLM_NUM_QUERIES \
    pdm_eval.enabled=$PDM_EVAL_ENABLED \
    pdm_eval.vlm_path=$PDM_EVAL_VLM_PATH \
    pdm_eval.vlm_profile=$VLM_PROFILE \
    pdm_eval.vlm_system_prompt="$PDM_EVAL_VLM_SYSTEM_PROMPT" \
    pdm_eval.vlm_cache_strategy=$PDM_EVAL_VLM_CACHE_STRATEGY
