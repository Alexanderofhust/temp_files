#    Copyright (C) 2026 Xiaomi Corporation.

from __future__ import annotations

from pathlib import Path
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple
import json
import logging
import os
import time
import traceback

import hydra
from hydra.utils import instantiate
from omegaconf import DictConfig, open_dict
import torch
import torch.distributed as dist
from diffusers.pipelines.ltx.pipeline_ltx_condition import LTXVideoCondition
from diffusers.utils import export_to_video
from PIL import Image

from nuplan.planning.script.builders.logging_builder import build_logger

from navsim.common.dataloader import SceneLoader, SceneFilter, MetricCacheLoader
from navsim.common.dataclasses import SensorConfig
from navsim.agents.videodrive.videodrive_agent import denorm_odo


logger = logging.getLogger(__name__)

CONFIG_PATH = "config/videodrive_video_export"
CONFIG_NAME = "default_run_videodrive_video_export"


def _as_bool(value: Any) -> bool:
    if isinstance(value, str):
        return value.strip().lower() in ("1", "true", "yes", "y")
    return bool(value)


def _rank() -> int:
    return dist.get_rank() if dist.is_available() and dist.is_initialized() else 0


def _world_size() -> int:
    return dist.get_world_size() if dist.is_available() and dist.is_initialized() else 1


def _local_indices(total_size: int, world_size: int, rank: int) -> range:
    shard_size = total_size // world_size
    left = total_size % world_size
    shard_sizes = [shard_size + int(r < left) for r in range(world_size)]
    begin = sum(shard_sizes[:rank])
    end = min(sum(shard_sizes[: rank + 1]), total_size)
    return range(begin, end)


def _init_distributed() -> torch.device:
    local_rank = int(os.getenv("LOCAL_RANK", 0))
    world_size = int(os.getenv("WORLD_SIZE", 1))
    rank = int(os.getenv("RANK", 0))

    if torch.cuda.is_available():
        torch.cuda.set_device(local_rank)
        device = torch.device(f"cuda:{local_rank}")
    else:
        device = torch.device("cpu")

    if world_size > 1 or "RANK" in os.environ:
        timeout_seconds = int(os.getenv("TORCH_DISTRIBUTED_TIMEOUT_SECONDS", str(600 * 60)))
        if not dist.is_initialized():
            dist.init_process_group(
                backend="nccl" if torch.cuda.is_available() else "gloo",
                world_size=world_size,
                rank=rank,
                timeout=timedelta(seconds=timeout_seconds),
            )
    return device


def _barrier() -> None:
    if dist.is_available() and dist.is_initialized():
        dist.barrier()


def _agent_get(cfg: DictConfig, key: str, default: Any = None) -> Any:
    agent_cfg = cfg.agent
    return agent_cfg.get(key, default) if hasattr(agent_cfg, "get") else getattr(agent_cfg, key, default)


def _use_vlm_condition(cfg: DictConfig) -> bool:
    return _as_bool(_agent_get(cfg, "use_vlm_condition", False))


def _normalize_vlm_strategy(strategy: str) -> str:
    return str(strategy or "").strip().lower()


def _apply_video_export_runtime(cfg: DictConfig) -> None:
    strategy = _normalize_vlm_strategy(_agent_get(cfg, "vlm_cache_strategy", "coc_reforward"))
    if strategy not in ("coc_reforward", "prompt_forward", "direct_forward"):
        raise ValueError(
            "video export supports vlm_cache_strategy='coc_reforward', "
            "'prompt_forward', or 'direct_forward'; got "
            f"{_agent_get(cfg, 'vlm_cache_strategy', None)!r}"
        )
    with open_dict(cfg.agent):
        cfg.agent.vlm_cache_strategy = strategy


def _select_tokens(cfg: DictConfig) -> List[str]:
    scene_loader = SceneLoader(
        sensor_blobs_path=None,
        data_path=Path(cfg.navsim_log_path),
        scene_filter=instantiate(cfg.train_test_split.scene_filter),
        sensor_config=SensorConfig.build_no_sensors(),
    )
    tokens = sorted(scene_loader.tokens)

    if _as_bool(cfg.video_export.require_metric_cache):
        metric_cache_loader = MetricCacheLoader(Path(cfg.metric_cache_path))
        metric_tokens = set(metric_cache_loader.tokens)
        tokens = sorted(set(tokens) & metric_tokens)

    max_scenarios = int(cfg.video_export.max_scenarios)
    if max_scenarios > 0:
        tokens = tokens[:max_scenarios]
    return tokens


def _build_features_like_pdm(agent, agent_input, scene) -> Tuple[Dict[str, torch.Tensor], Dict[str, torch.Tensor]]:
    features: Dict[str, torch.Tensor] = {}
    targets: Dict[str, torch.Tensor] = {}

    for builder in agent.get_feature_builders():
        features.update(builder.compute_features(agent_input))
    for builder in agent.get_target_builders():
        targets.update(builder.compute_targets(scene))

    agent._maybe_load_feature_images_from_paths(features)

    vlm_condition = agent._get_vlm_condition(agent_input, scene)
    if vlm_condition is not None:
        vlm_hidden_state, vlm_attention_mask = vlm_condition
        features["vlm_last_hidden_state"] = vlm_hidden_state
        if vlm_attention_mask is not None:
            features["vlm_attention_mask"] = vlm_attention_mask

    return {k: v.unsqueeze(0) for k, v in features.items()}, targets


def _default_prompt() -> str:
    return (
        "A high-quality, photorealistic dashboard camera view of autonomous driving. "
        "Based on the past 2 seconds videos, "
        "predict and generate the next 4 seconds of realistic driving continuation, "
        "Maintain temporal consistency, stable camera perspective, natural motion flow without jitter or artifacts, "
        "clear details, and realistic physics. "
    )


def _coerce_video_batches(video: Any) -> List[List[Image.Image]]:
    if video is None:
        return []
    if isinstance(video, Image.Image):
        return [[video]]
    if isinstance(video, (list, tuple)):
        if not video:
            return []
        if isinstance(video[0], Image.Image):
            return [list(video)]
        if isinstance(video[0], (list, tuple)) and video[0] and isinstance(video[0][0], Image.Image):
            return [list(frames) for frames in video]
    raise TypeError(f"Unsupported video output type for saving: {type(video)!r}")


def _save_frames(frames: List[Image.Image], path: Path, fps: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    export_to_video(frames, str(path), fps=fps)


@torch.inference_mode()
def _run_video_forward_like_pdm(agent, features: Dict[str, torch.Tensor], cfg: DictConfig) -> Dict[str, Any]:
    device = agent.device
    args = agent.args
    export_cfg = cfg.video_export
    weight_dtype = agent.weight_dtype

    cond_tensor = features["images"]
    if cond_tensor.ndim == 5:
        cond_tensor = cond_tensor.squeeze(0)
    elif cond_tensor.ndim != 4:
        raise ValueError(f"Expected features['images'] with shape (B,T,C,H,W) or (T,C,H,W), got {cond_tensor.shape}")

    context_dict = {
        "hist_traj": features["history_trajectory"].to(device, dtype=weight_dtype),
        "cmd_onehot": features["driving_command"].to(device, dtype=weight_dtype),
        "vel": features["vel"].to(device, dtype=weight_dtype),
        "acc": features["acc"].to(device, dtype=weight_dtype),
    }

    vlm_hidden_states = features.get("vlm_last_hidden_state")
    vlm_attention_mask = features.get("vlm_attention_mask")
    if vlm_hidden_states is not None:
        vlm_hidden_states = vlm_hidden_states.to(device, dtype=weight_dtype)
    if vlm_attention_mask is not None:
        vlm_attention_mask = vlm_attention_mask.to(device=device, dtype=torch.bool)
        if bool(vlm_attention_mask.all().item()):
            vlm_attention_mask = None

    cond_pils = agent._tensor_video_to_pils(cond_tensor)
    condition = LTXVideoCondition(video=cond_pils, frame_index=0)

    if agent.view_mode == "surround6":
        height, width = 256, 3072
    else:
        height = int(export_cfg.height)
        width = int(export_cfg.width)

    seed = int(export_cfg.seed)
    generator = torch.Generator(device=device).manual_seed(seed)

    out = agent.pipe.infer(
        conditions=[condition],
        prompt=str(export_cfg.prompt or _default_prompt()),
        negative_prompt=str(export_cfg.negative_prompt),
        num_inference_steps=int(export_cfg.num_inference_steps),
        guidance_scale=float(export_cfg.guidance_scale),
        height=height,
        width=width,
        generator=generator,
        num_frames=int(export_cfg.num_frames),
        output_type="pil",
        return_action=True,
        return_video=True,
        action_chunk=int(getattr(args, "action_chunk", export_cfg.action_chunk)),
        action_dim=int(getattr(args, "action_dim", export_cfg.action_dim)),
        context_dict=context_dict,
        vlm_hidden_states=vlm_hidden_states,
        vlm_attention_mask=vlm_attention_mask,
        noise_seed=int(export_cfg.noise_seed),
        pixel_wise_timestep=bool(getattr(args, "pixel_wise_timestep", True)),
        image_cond_noise_scale=float(export_cfg.image_cond_noise_scale),
    )

    videos = out["videos"] if isinstance(out, dict) else out.frames
    actions = out.get("actions") if isinstance(out, dict) else None
    action_array = None
    if actions is not None:
        action_array = denorm_odo(actions)[0].detach().float().cpu().numpy()

    return {
        "history_frames": cond_pils,
        "video_batches": _coerce_video_batches(videos),
        "actions": action_array,
    }


def _write_json(path: Path, data: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def _write_jsonl(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def _merge_rank_metadata(output_dir: Path, world_size: int) -> None:
    rows: List[Dict[str, Any]] = []
    for rank in range(world_size):
        rank_path = output_dir / f"metadata_rank{rank}.jsonl"
        if not rank_path.exists():
            continue
        with rank_path.open("r") as f:
            for line in f:
                line = line.strip()
                if line:
                    rows.append(json.loads(line))
    rows = sorted(rows, key=lambda x: (str(x.get("token", "")), int(x.get("rank", 0))))
    _write_jsonl(output_dir / "metadata.jsonl", rows)


def _process_tokens(cfg: DictConfig, tokens: List[str], device: torch.device) -> List[Dict[str, Any]]:
    rank = _rank()
    world_size = _world_size()
    local_tokens = [tokens[i] for i in _local_indices(len(tokens), world_size, rank)]

    agent = instantiate(cfg.agent)
    agent.initialize()
    if torch.cuda.is_available() and str(agent.device) == "cuda":
        agent.device = str(device)
    agent.eval()

    log_lookup_filter: SceneFilter = instantiate(cfg.train_test_split.scene_filter)
    log_lookup_filter.tokens = local_tokens
    log_lookup_loader = SceneLoader(
        sensor_blobs_path=None,
        data_path=Path(cfg.navsim_log_path),
        scene_filter=log_lookup_filter,
        sensor_config=SensorConfig.build_no_sensors(),
    )
    local_log_names = sorted(set(log_lookup_loader.token_to_log_file.values()))

    scene_filter: SceneFilter = instantiate(cfg.train_test_split.scene_filter)
    scene_filter.tokens = local_tokens
    scene_filter.log_names = local_log_names
    scene_loader = SceneLoader(
        sensor_blobs_path=Path(cfg.sensor_blobs_path),
        data_path=Path(cfg.navsim_log_path),
        scene_filter=scene_filter,
        sensor_config=agent.get_sensor_config(),
        load_image_path=_use_vlm_condition(cfg),
    )

    output_dir = Path(cfg.video_export.output_dir)
    fps = int(cfg.video_export.fps)
    future_start = int(cfg.video_export.future_start_frame)
    rows: List[Dict[str, Any]] = []

    logger.info("Rank %d exporting %d/%d tokens", rank, len(local_tokens), len(tokens))
    for local_idx, token in enumerate(local_tokens):
        safe_token = str(token).replace("/", "_")
        token_dir = output_dir / f"{safe_token}"
        row: Dict[str, Any] = {
            "token": token,
            "rank": rank,
            "valid": True,
            "output_dir": str(token_dir),
            "vlm_cache_strategy": _agent_get(cfg, "vlm_cache_strategy"),
            "num_inference_steps": int(cfg.video_export.num_inference_steps),
        }
        start_time = time.perf_counter()
        try:
            scene = scene_loader.get_scene_from_token(token)
            agent_input = scene_loader.get_agent_input_from_token(token)
            features, _ = _build_features_like_pdm(agent, agent_input, scene)
            result = _run_video_forward_like_pdm(agent, features, cfg)

            video_batches = result["video_batches"]
            if not video_batches:
                raise RuntimeError("Pipeline returned no video frames.")
            pred_frames = video_batches[0]

            if bool(cfg.video_export.save_history_video):
                _save_frames(result["history_frames"], token_dir / "input_history.mp4", fps=fps)
            if bool(cfg.video_export.save_full_video):
                _save_frames(pred_frames, token_dir / "pred_full.mp4", fps=fps)
            future_frames = pred_frames[future_start:] if future_start > 0 else pred_frames
            _save_frames(future_frames, token_dir / "pred_future.mp4", fps=fps)

            actions = result["actions"]
            if bool(cfg.video_export.save_actions) and actions is not None:
                import numpy as np

                np.save(token_dir / "actions.npy", actions)
                row["actions_shape"] = list(actions.shape)

            row["num_pred_frames"] = len(pred_frames)
            row["num_future_frames"] = len(future_frames)
            row["elapsed_sec"] = time.perf_counter() - start_time
            if bool(cfg.video_export.save_metadata):
                _write_json(token_dir / "metadata.json", row)
            logger.info(
                "[Rank %d] Exported %s (%d/%d) in %.3fs",
                rank,
                token,
                local_idx + 1,
                len(local_tokens),
                row["elapsed_sec"],
            )
        except Exception as exc:
            row["valid"] = False
            row["error"] = repr(exc)
            traceback.print_exc()
            logger.warning("[Rank %d] Failed to export token %s: %s", rank, token, exc)
        rows.append(row)
    return rows


@hydra.main(config_path=CONFIG_PATH, config_name=CONFIG_NAME, version_base=None)
def main(cfg: DictConfig) -> None:
    device = _init_distributed()
    _apply_video_export_runtime(cfg)
    build_logger(cfg)

    output_dir = Path(cfg.video_export.output_dir)
    if _rank() == 0:
        output_dir.mkdir(parents=True, exist_ok=True)

    tokens = _select_tokens(cfg)
    if not tokens:
        raise RuntimeError("No tokens selected for VideoDrive video export.")

    logger.info(
        "Starting VideoDrive video export: tokens=%d, steps=%d, vlm_strategy=%s, output=%s",
        len(tokens),
        int(cfg.video_export.num_inference_steps),
        _agent_get(cfg, "vlm_cache_strategy"),
        output_dir,
    )

    rows = _process_tokens(cfg, tokens, device)
    _write_jsonl(output_dir / f"metadata_rank{_rank()}.jsonl", rows)
    _barrier()

    if _rank() == 0:
        _merge_rank_metadata(output_dir, _world_size())
        logger.info("Finished VideoDrive video export. Metadata: %s", output_dir / "metadata.jsonl")

    _barrier()
    if dist.is_available() and dist.is_initialized():
        dist.destroy_process_group()


if __name__ == "__main__":
    main()
