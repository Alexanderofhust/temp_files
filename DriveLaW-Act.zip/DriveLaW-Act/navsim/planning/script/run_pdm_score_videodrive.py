#    Copyright (C) 2026 Xiaomi Corporation.

#    Licensed under the Apache License, Version 2.0 (the "License");
#    you may not use this file except in compliance with the License.
#    You may obtain a copy of the License at

#        http://www.apache.org/licenses/LICENSE-2.0

#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS,
#    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#    See the License for the specific language governing permissions and
#    limitations under the License.
from typing import Any, Dict, List, Union, Tuple
from pathlib import Path
from dataclasses import asdict
from datetime import datetime, timedelta
import traceback
import logging
import lzma
import pickle
import os
import uuid
import time
import torch
import torch.distributed as dist
import hydra
from hydra.utils import instantiate
from omegaconf import DictConfig, open_dict
import pandas as pd
from yaml import load, Loader

from nuplan.planning.script.builders.logging_builder import build_logger

from navsim.agents.abstract_agent import AbstractAgent
from navsim.common.dataloader import SceneLoader, SceneFilter, MetricCacheLoader
from navsim.common.dataclasses import SensorConfig
from navsim.evaluate.pdm_score import pdm_score
from navsim.planning.simulation.planner.pdm_planner.simulation.pdm_simulator import PDMSimulator
from navsim.planning.simulation.planner.pdm_planner.scoring.pdm_scorer import PDMScorer
from navsim.planning.metric_caching.metric_cache import MetricCache

logger = logging.getLogger(__name__)

CONFIG_PATH = "config/pdm_scoring"
CONFIG_NAME = "default_run_pdm_score"


def _as_bool(value) -> bool:
    if isinstance(value, str):
        return value.strip().lower() in ("1", "true", "yes", "y")
    return bool(value)


def _agent_get(cfg: DictConfig, key: str, default=None):
    agent_cfg = cfg.agent
    return agent_cfg.get(key, default) if hasattr(agent_cfg, "get") else getattr(agent_cfg, key, default)


def _use_vlm_condition(cfg: DictConfig) -> bool:
    return _as_bool(_agent_get(cfg, "use_vlm_condition", False))


def _vlm_mode(cfg: DictConfig) -> str:
    return str(_agent_get(cfg, "vlm_mode", "online")).lower()


def _should_load_image_paths(cfg: DictConfig) -> bool:
    return _use_vlm_condition(cfg)


def _apply_agent_config_eval_runtime(cfg: DictConfig) -> None:
    config_file = _agent_get(cfg, "config_file", "")
    if not config_file:
        return
    with open(config_file, "r") as f:
        agent_file_cfg = load(f, Loader=Loader) or {}
    eval_runtime = agent_file_cfg.get("eval_runtime", {}) or {}
    if not eval_runtime:
        return
    with open_dict(cfg.agent):
        for key, value in eval_runtime.items():
            cfg.agent[key] = value


class InferenceSampler(torch.utils.data.sampler.Sampler):
    def __init__(self, size):
        self._size = int(size)
        assert size > 0
        self._rank = dist.get_rank()
        self._world_size = dist.get_world_size()
        self._local_indices = self._get_local_indices(size, self._world_size, self._rank)

    @staticmethod
    def _get_local_indices(total_size, world_size, rank):
        shard_size = total_size // world_size
        left = total_size % world_size
        shard_sizes = [shard_size + int(r < left) for r in range(world_size)]

        begin = sum(shard_sizes[:rank])
        end = min(sum(shard_sizes[:rank + 1]), total_size)
        return range(begin, end)

    def __iter__(self):
        yield from self._local_indices

    def __len__(self):
        return len(self._local_indices)


def run_pdm_score(args: List[Dict[str, Union[List[str], DictConfig]]]) -> List[Dict[str, Any]]:
    """
    Helper function to run PDMS evaluation in.
    :param args: input arguments
    """
    node_id = int(os.environ.get("NODE_RANK", 0))
    thread_id = str(uuid.uuid4())
    logger.info(f"Starting worker in thread_id={thread_id}, node_id={node_id}")

    log_names = [a["log_file"] for a in args]
    tokens = [t for a in args for t in a["tokens"]]
    cfg: DictConfig = args[0]["cfg"]

    simulator: PDMSimulator = instantiate(cfg.simulator)
    scorer: PDMScorer = instantiate(cfg.scorer)
    assert (
        simulator.proposal_sampling == scorer.proposal_sampling
    ), "Simulator and scorer proposal sampling has to be identical"
    agent: AbstractAgent = instantiate(cfg.agent)
    agent.initialize()

    metric_cache_loader = MetricCacheLoader(Path(cfg.metric_cache_path))
    scene_filter: SceneFilter = instantiate(cfg.train_test_split.scene_filter)
    scene_filter.log_names = log_names
    scene_filter.tokens = tokens
    scene_loader = SceneLoader(
        sensor_blobs_path=Path(cfg.sensor_blobs_path),
        data_path=Path(cfg.navsim_log_path),
        scene_filter=scene_filter,
        sensor_config=agent.get_sensor_config(),
        load_image_path=_should_load_image_paths(cfg),
    )

    tokens_to_evaluate = list(set(scene_loader.tokens) & set(metric_cache_loader.tokens))
    tokens_to_evaluate = sorted(tokens_to_evaluate) 
    # Use DistributedSampler to split the tokens for each GPU
    
    # Distribute tasks to different GPUs by iterating over the sampled tokens
    pdm_results: List[Dict[str, Any]] = []
    inference_times: List[float] = []  
    
    for idx, (token) in enumerate(tokens_to_evaluate):
        if dist.get_rank() == 0:
            logger.info(f"Rank {dist.get_rank()} processing scenario {idx+1} / {len(tokens_to_evaluate)} in thread_id={thread_id}, node_id={node_id}")

        score_row: Dict[str, Any] = {"token": token, "valid": True}
        inference_time = None
        try:
            metric_cache_path = metric_cache_loader.metric_cache_paths[token]
            with lzma.open(metric_cache_path, "rb") as f:
                metric_cache: MetricCache = pickle.load(f)

            agent_input = scene_loader.get_agent_input_from_token(token)
            requires_scene=True
            if requires_scene:
                scene = scene_loader.get_scene_from_token(token)
            
            torch.cuda.synchronize()  
            start_time = time.perf_counter()
            
            if requires_scene:
                trajectory = agent.compute_trajectory(agent_input, scene)
            else:
                trajectory = agent.compute_trajectory(agent_input)
            
            torch.cuda.synchronize()  
            end_time = time.perf_counter()
            inference_time = end_time - start_time  
            inference_times.append(inference_time)
            
            timing_info = getattr(agent, 'last_inference_timing', {})
            
            timing_str = f"total={inference_time:.4f}s"
            if timing_info:
                parts = []
                if 'feature_building' in timing_info:
                    parts.append(f"feature_building={timing_info['feature_building']:.4f}s")
                if 'image_preprocessing' in timing_info:
                    parts.append(f"image_preprocessing={timing_info['image_preprocessing']:.4f}s")
                if 'pipe_infer' in timing_info:
                    parts.append(f"pipe_infer={timing_info['pipe_infer']:.4f}s")
                if 'action_postprocessing' in timing_info:
                    parts.append(f"action_postprocessing={timing_info['action_postprocessing']:.4f}s")
                if 'forward_pass' in timing_info:
                    parts.append(f"forward_pass={timing_info['forward_pass']:.4f}s")
                if parts:
                    timing_str += " [" + ", ".join(parts) + "]"
            
            logger.info(f"[Rank {dist.get_rank()}] Token {token}: inference time = {timing_str}")
            
            score_row['inference_time_breakdown'] = timing_info
            
            pdm_result = pdm_score(
                metric_cache=metric_cache,
                model_trajectory=trajectory,
                future_sampling=simulator.proposal_sampling,
                simulator=simulator,
                scorer=scorer,
            )
            score_row.update(asdict(pdm_result))
            score_row['rank'] = dist.get_rank()
            score_row['inference_time'] = inference_time  
        except Exception as e:
            logger.warning(f"----------- Agent failed for token {token}:")
            traceback.print_exc()
            score_row["valid"] = False
            score_row['inference_time'] = None
            score_row['inference_time_breakdown'] = {}

        pdm_results.append(score_row)
        
        if (idx + 1) % 10 == 0 or (idx + 1) == len(tokens_to_evaluate):
            if inference_times:
                current_avg = sum(inference_times) / len(inference_times)
                logger.info(f"[Rank {dist.get_rank()}] Progress: {idx+1}/{len(tokens_to_evaluate)} scenarios processed. Current average inference time: {current_avg:.4f} seconds ({len(inference_times)} valid trajectories)")
    
    if inference_times:
        avg_inference_time = sum(inference_times) / len(inference_times)
        logger.info(f"[Rank {dist.get_rank()}] Final average inference time per trajectory: {avg_inference_time:.4f} seconds ({len(inference_times)} valid trajectories)")
    serialized_score_rows = pickle.dumps(pdm_results)
    return serialized_score_rows

def broadcast_object(obj: Any, device: torch.device, src: int = 0) -> Any:
    """
    Helper function to broadcast an object from the source rank to all other processes.
    :param obj: Object to broadcast.
    :param device: Device to use for tensor operations.
    :param src: Source rank.
    :return: Broadcasted object.
    """
    if dist.get_rank() == src:
        buffer = pickle.dumps(obj)
        tensor = torch.ByteTensor(list(buffer)).to(device)
        size_tensor = torch.tensor(len(tensor)).to(device)
        dist.broadcast(size_tensor, src=src)
        dist.broadcast(tensor, src=src)
    else:
        size_tensor = torch.tensor(0).to(device)
        dist.broadcast(size_tensor, src=src)
        tensor = torch.ByteTensor(size_tensor.item()).to(device)
        dist.broadcast(tensor, src=src)
        buffer = tensor.cpu().numpy().tobytes()
        obj = pickle.loads(buffer)
    return obj


@hydra.main(config_path=CONFIG_PATH, config_name=CONFIG_NAME, version_base=None)
def main(cfg: DictConfig) -> None:
    """
    Main entrypoint for running PDMS evaluation.
    :param cfg: omegaconf dictionary
    """
    local_rank = int(os.getenv('LOCAL_RANK', 0))
    world_size = int(os.getenv('WORLD_SIZE', 1))
    rank = int(os.getenv('RANK', 0))
    timeout_seconds = int(os.getenv("TORCH_DISTRIBUTED_TIMEOUT_SECONDS", str(600 * 60)))
    torch.cuda.set_device(local_rank)

    dist.init_process_group(
        backend='nccl',
        world_size=world_size,
        rank=rank,
        timeout=timedelta(seconds=timeout_seconds),
    )
    
    device = torch.device(f'cuda:{local_rank}')  

    _apply_agent_config_eval_runtime(cfg)
    build_logger(cfg)
    if _use_vlm_condition(cfg) and _vlm_mode(cfg) != "online":
        raise ValueError("VideoDrive PDM evaluation now requires agent.vlm_mode=online; VLM cache evaluation is disabled.")

    # Extract scenes based on scene-loader to know which tokens to distribute across workers
    # TODO: infer the tokens per log from metadata, to not have to load metric cache and scenes here
    # scene_loader = SceneLoader(
    #     sensor_blobs_path=None,
    #     data_path=Path(cfg.navsim_log_path),
    #     scene_filter=instantiate(cfg.train_test_split.scene_filter),
    #     sensor_config=SensorConfig.build_no_sensors(),
    # )
    # metric_cache_loader = MetricCacheLoader(Path(cfg.metric_cache_path))

    # tokens_to_evaluate = list(set(scene_loader.tokens) & set(metric_cache_loader.tokens))
    scene_loader = SceneLoader(
            sensor_blobs_path=None,
            data_path=Path(cfg.navsim_log_path),
            scene_filter=instantiate(cfg.train_test_split.scene_filter),
            sensor_config=SensorConfig.build_no_sensors(),
        )
    if rank == 0:
        metric_cache_loader = MetricCacheLoader(Path(cfg.metric_cache_path))
        tokens_to_evaluate = list(set(scene_loader.tokens) & set(metric_cache_loader.tokens))
        tokens_to_evaluate = sorted(tokens_to_evaluate)  
        num_missing_metric_cache_tokens = len(set(scene_loader.tokens) - set(metric_cache_loader.tokens))
        num_unused_metric_cache_tokens = len(set(metric_cache_loader.tokens) - set(scene_loader.tokens))
        if num_missing_metric_cache_tokens > 0:
            logger.warning(f"Missing metric cache for {num_missing_metric_cache_tokens} tokens. Skipping these tokens.")
        if num_unused_metric_cache_tokens > 0:
            logger.warning(f"Unused metric cache for {num_unused_metric_cache_tokens} tokens. Skipping these tokens.")
    else:
        tokens_to_evaluate = []


    tokens_to_evaluate = broadcast_object(tokens_to_evaluate, device=device, src=0)
    if not tokens_to_evaluate:
        raise RuntimeError("No common tokens between PDM eval split and metric cache.")


    logger.info("Starting pdm scoring of %s scenarios...", str(len(tokens_to_evaluate)))
    # data_points = [
    #     {
    #         "cfg": cfg,
    #         "log_file": log_file,
    #         "tokens": tokens_list,
    #     }
    #     for log_file, tokens_list in scene_loader.get_tokens_list_per_log().items()
    # ]
    sampler = InferenceSampler(len(tokens_to_evaluate))

    data_points = []
    for idx in sampler:
        token = tokens_to_evaluate[idx]
        log_file = scene_loader.token_to_log_file[token]  
        data_points.append({
            "cfg": cfg,
            "log_file": log_file,
            "tokens": [token],  
        })

    if data_points:
        serialized_score_rows = run_pdm_score(data_points)
    else:
        serialized_score_rows = pickle.dumps([])

    # Convert the serialized result into a tensor (byte string)
    gather_device = torch.device(f"cuda:{local_rank}")
    # serialized_score_rows is a byte string, so we treat it as a tensor directly
    serialized_tensor = torch.ByteTensor(list(serialized_score_rows)).to(gather_device)

    # Step 1: Gather tensor sizes across all GPUs
    local_size = len(serialized_tensor)
    local_size_tensor = torch.tensor(local_size, device=gather_device)
    size_list = [torch.zeros_like(local_size_tensor) for _ in range(dist.get_world_size())]
    dist.all_gather(size_list, local_size_tensor)

    # Step 2: Determine the maximum size
    max_size = max(int(size.item()) for size in size_list)  # Maximum size across all GPUs

    # Step 3: Pad the tensors to match the maximum size
    if local_size < max_size:
        padded_tensor = torch.cat([
            serialized_tensor,
            torch.zeros(max_size - local_size, dtype=torch.uint8, device=gather_device),
        ])
    else:
        padded_tensor = serialized_tensor

    # Step 4: Perform all_gather on the padded tensors
    gathered_results = [torch.empty_like(padded_tensor) for _ in range(dist.get_world_size())]
    dist.all_gather(gathered_results, padded_tensor)

    # Step 5: After gathering, deserialize the data (should be done after gathering)
    if dist.get_rank() == 0:
        final_results = []
        for gathered_tensor, rank_size in zip(gathered_results, size_list):
            # Trim off the per-rank padding before deserializing.
            gathered_tensor = gathered_tensor[: int(rank_size.item())]
            serialized_data = gathered_tensor.cpu().numpy().tobytes()
            final_results.extend(pickle.loads(serialized_data))  # 
    # Now final_results contains the combined results from all GPUs
    # You can continue processing here, like saving the results to a file
    
        pdm_score_df = pd.DataFrame(final_results).sort_values("token").reset_index(drop=True)

        num_sucessful_scenarios = pdm_score_df["valid"].sum()
        num_failed_scenarios = len(pdm_score_df) - num_sucessful_scenarios
        
        valid_inference_times = pdm_score_df[pdm_score_df["valid"] == True]["inference_time"].dropna()
        global_avg_inference_time = None
        if len(valid_inference_times) > 0:
            global_avg_inference_time = valid_inference_times.mean()
            logger.info(f"[Global] Average inference time per trajectory across all GPUs: {global_avg_inference_time:.4f} seconds ({len(valid_inference_times)} valid trajectories)")
        
        cols_to_drop = ["token", "valid", "rank"]
        if "inference_time" in pdm_score_df.columns:
            cols_to_drop.append("inference_time")
        if "inference_time_breakdown" in pdm_score_df.columns:
            cols_to_drop.append("inference_time_breakdown")
        average_row = pdm_score_df.drop(columns=cols_to_drop).mean(skipna=True)
        average_row["token"] = "average"
        average_row["valid"] = pdm_score_df["valid"].all()
        average_row["rank"] = "0"
        if global_avg_inference_time is not None:
            average_row["inference_time"] = global_avg_inference_time
        pdm_score_df.loc[len(pdm_score_df)] = average_row

        save_path = Path(cfg.output_dir)
        timestamp = datetime.now().strftime("%Y.%m.%d.%H.%M.%S")
        pdm_score_df.to_csv(save_path / f"{timestamp}.csv")

        log_info = f"""
            Finished running evaluation.
                Number of successful scenarios: {num_sucessful_scenarios}.
                Number of failed scenarios: {num_failed_scenarios}.
                Final average score of valid results: {pdm_score_df['score'].mean()}."""
        
        if global_avg_inference_time is not None:
            log_info += f"""
                Average inference time per trajectory: {global_avg_inference_time:.4f} seconds."""
        
        log_info += f"""
                Results are stored in: {save_path / f"{timestamp}.csv"}."""
        
        logger.info(log_info)


if __name__ == "__main__":
    main()
