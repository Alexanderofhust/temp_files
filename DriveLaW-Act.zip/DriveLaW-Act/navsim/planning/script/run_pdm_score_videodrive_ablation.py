from navsim.planning.script.run_pdm_score_videodrive import main


if __name__ == "__main__":
    main()
