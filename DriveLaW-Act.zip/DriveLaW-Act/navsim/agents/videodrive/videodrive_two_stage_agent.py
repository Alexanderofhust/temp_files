#    Copyright (C) 2026 Xiaomi Corporation.

from typing import Optional

from .videodrive_agent import VideoDriveAgent


class VideoDriveTwoStageAgent(VideoDriveAgent):
    """VideoDrive agent variant used by the isolated two-stage trainer."""

    def __init__(self, diffusion_model_path: Optional[str] = "", **kwargs):
        super().__init__(**kwargs)
        if diffusion_model_path:
            self.args.diffusion_model["model_path"] = str(diffusion_model_path)
