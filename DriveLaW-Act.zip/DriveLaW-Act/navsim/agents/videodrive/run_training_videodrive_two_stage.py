#    Copyright (C) 2026 Xiaomi Corporation.

import math
import os
from pathlib import Path

import hydra
import torch
from diffusers.optimization import get_scheduler
from diffusers.training_utils import EMAModel, cast_training_params
from omegaconf import DictConfig, OmegaConf, open_dict

try:
    from navsim.agents.videodrive.run_training_videodrive import (
        UnifiedTrainer,
        get_optimizer,
        logger,
        unwrap_model,
    )
except ImportError:
    from run_training_videodrive import (
        UnifiedTrainer,
        get_optimizer,
        logger,
        unwrap_model,
    )


CONFIG_PATH = str(Path(__file__).resolve().parents[2] / "planning" / "script" / "config" / "training")
CONFIG_NAME = "default_training_two_stage"
DEFAULT_CONFIG_FILE = str(Path(__file__).resolve().parent / "configs" / "ltx_model" / "video_model_two_stage_train_navsim.yaml")


class TwoStageVideoDriveTrainer(UnifiedTrainer):
    """Small wrapper around UnifiedTrainer for the isolated two-stage schedule."""

    def _stage_cfg(self):
        return self._cfg_get("two_stage", {}) or {}

    def _stage_get(self, key: str, default=None):
        return self._node_get(self._stage_cfg(), key, default)

    def _stage_has(self, key: str) -> bool:
        stage_cfg = self._stage_cfg()
        if hasattr(stage_cfg, "__contains__"):
            return key in stage_cfg
        return hasattr(stage_cfg, key)

    def _apply_ltx_runtime_config_to_hydra_cfg(self):
        super()._apply_ltx_runtime_config_to_hydra_cfg()
        stage_cfg = self._stage_cfg()
        if not stage_cfg:
            return

        with open_dict(self.cfg):
            grad_accum = self._stage_get("gradient_accumulation_steps", None)
            if grad_accum is not None:
                self.cfg.gradient_accumulation_steps = int(grad_accum)

            if "dataloader" not in self.cfg or self.cfg.dataloader is None:
                self.cfg.dataloader = OmegaConf.create({"params": {}})
            if "params" not in self.cfg.dataloader or self.cfg.dataloader.params is None:
                self.cfg.dataloader.params = OmegaConf.create({})

            batch_size = self._stage_get("batch_size", None)
            if batch_size is not None:
                self.cfg.dataloader.params.batch_size = int(batch_size)
            num_workers = self._stage_get("dataloader_num_workers", None)
            if num_workers is not None:
                self.cfg.dataloader.params.num_workers = int(num_workers)
            pin_memory = self._stage_get("pin_memory", None)
            if pin_memory is not None:
                self.cfg.dataloader.params.pin_memory = self._as_bool(pin_memory)

            for key in ("vlm_cache_path", "vlm_profile", "vlm_feature_name", "vlm_hidden_state_key"):
                if self._stage_has(key):
                    value = self._stage_get(key)
                    if key == "vlm_cache_path" and value in (None, ""):
                        continue
                    self.cfg[key] = str(value)
            if self._stage_has("use_vlm_condition"):
                self.cfg.use_vlm_condition = self._as_bool(self._stage_get("use_vlm_condition"))

            if "agent" in self.cfg and self.cfg.agent is not None:
                diffusion_model_path = self._stage_get("diffusion_model_path", "")
                if diffusion_model_path:
                    self.cfg.agent.diffusion_model_path = str(diffusion_model_path)
                for key in (
                    "vlm_profile",
                    "vlm_hidden_dim",
                    "vlm_feature_name",
                    "vlm_hidden_state_key",
                    "joint_vlm_enable",
                    "joint_video_attend_vlm",
                    "cross_attention_vlm_enable",
                    "vlm_compress_tokens",
                    "vlm_num_queries",
                ):
                    if self._stage_has(key):
                        value = self._stage_get(key)
                        self.cfg.agent[key] = value

    def _apply_hydra_runtime_overrides_to_args(self):
        super()._apply_hydra_runtime_overrides_to_args()
        stage_cfg = self._stage_cfg()
        if not stage_cfg:
            return

        scalar_overrides = {
            "train_mode": str,
            "batch_size": int,
            "dataloader_num_workers": int,
            "train_steps": int,
            "train_epochs": int,
            "steps_to_save": int,
            "steps_to_log": int,
            "steps_to_val": int,
            "lr": float,
            "lr_warmup_steps": int,
            "return_action": self._as_bool,
            "return_video": self._as_bool,
            "pin_memory": self._as_bool,
        }
        for key, caster in scalar_overrides.items():
            if self._stage_has(key):
                setattr(self.args, key, caster(self._stage_get(key)))

        if self._stage_has("stage_name"):
            setattr(self.args, "two_stage_name", str(self._stage_get("stage_name")))

        diffusion_model_path = self._stage_get("diffusion_model_path", "")
        if diffusion_model_path:
            self.args.diffusion_model["model_path"] = str(diffusion_model_path)

        diffusion_cfg = self.args.diffusion_model["config"]
        if self._stage_has("vlm_hidden_dim"):
            diffusion_cfg["vlm_hidden_dim"] = int(self._stage_get("vlm_hidden_dim"))
        bool_diffusion_overrides = (
            "joint_vlm_enable",
            "joint_video_attend_vlm",
            "cross_attention_vlm_enable",
            "vlm_compress_tokens",
        )
        for key in bool_diffusion_overrides:
            if self._stage_has(key):
                diffusion_cfg[key] = self._as_bool(self._stage_get(key))
        if self._stage_has("vlm_num_queries"):
            diffusion_cfg["vlm_num_queries"] = int(self._stage_get("vlm_num_queries"))

        grad_accum = self._stage_get("gradient_accumulation_steps", None)
        if grad_accum is not None:
            setattr(self.args, "gradient_accumulation_steps", int(grad_accum))

    def _init_save_folder(self):
        fixed_save_folder = str(self._stage_get("save_folder", "") or "")
        if not fixed_save_folder:
            return super()._init_save_folder()

        accel = self.state.accelerator
        save_folder = self._normalize_path(fixed_save_folder)
        values = [save_folder if accel.is_main_process else None]
        if accel.num_processes > 1:
            if not self._distributed_ready():
                raise RuntimeError("Distributed process group is not initialized; cannot broadcast save folder.")
            torch.distributed.broadcast_object_list(values, src=0)
        self.save_folder = values[0]
        self._set_cfg_output_dir(self.save_folder)
        self._assert_same_path_across_ranks(self.save_folder, "save_folder")

        if accel.is_main_process:
            os.makedirs(self.save_folder, exist_ok=True)
        accel.wait_for_everyone()
        logger.info("Using fixed two-stage save folder: %s", self.save_folder)
        self._set_tracker_dirs_to_save_folder()
        self._init_experiment_file_logging()

    @staticmethod
    def _action_vlm_no_video_trainable(name: str) -> bool:
        trainable_prefixes = (
            "action_state",
            "action_proj_in",
            "action_scale_shift_table",
            "action_time_embed",
            "action_ego_status_encoder",
            "action_his_traj_encoder",
            "action_state_film",
            "action_rope",
            "action_blocks",
            "action_proj_out",
            "action_proj_extra",
            "action_norm_out",
            "action_history_input_projector",
            "joint_vlm_projector",
            "joint_action_rope",
            "joint_vlm_blocks",
            "cross_attention_vlm_projector",
            "vlm_qformer",
            "traj_scorer",
        )
        return name.startswith(trainable_prefixes)

    def _set_requires_grad_for_mode(self, train_mode: str, name: str) -> bool:
        if train_mode == "action_vlm_no_video":
            return self._action_vlm_no_video_trainable(name)
        if train_mode == "action_only":
            return "action_" in name
        if train_mode == "video_only":
            return "action_" not in name
        if train_mode == "action_vlm_adapter":
            return any(
                key in name
                for key in (
                    "action_his_traj",
                    "action_history",
                    ".attn3",
                    ".norm3",
                    "cross_attention_vlm",
                    "joint_vlm",
                    "joint_action_rope",
                )
            )
        if train_mode in ("all", "action_full"):
            return True
        raise NotImplementedError(f"Unsupported train_mode: {train_mode}")

    def prepare_trainable_parameters(self):
        logger.info("Initializing trainable parameters for two-stage trainer")
        if self.args.mixed_precision == "fp16":
            cast_training_params([self.diffusion_model], dtype=torch.float32)

        if self.args.allow_tf32 and torch.cuda.is_available():
            torch.backends.cuda.matmul.allow_tf32 = True

        train_mode = self.args.train_mode
        trainable_params = []
        for name, p in self.diffusion_model.named_parameters():
            p.requires_grad = self._set_requires_grad_for_mode(train_mode, name)
            if p.requires_grad:
                trainable_params.append(p)

        if not trainable_params:
            raise RuntimeError(f"train_mode={train_mode!r} did not select any trainable parameters.")

        self.state.num_trainable_parameters = sum(p.numel() for p in trainable_params)
        logger.info("Trainable params: %s", self.state.num_trainable_parameters)

        if self.state.accelerator.is_main_process:
            def _format_param(name: str, p: torch.nn.Parameter) -> str:
                try:
                    shape_str = str(tuple(p.shape))
                except Exception:
                    shape_str = "<no-shape>"
                try:
                    n = p.numel()
                except Exception:
                    n = 0
                return f"{name:<80} | shape={shape_str:<22} | numel={n:>12d} | requires_grad={p.requires_grad}"

            trainables = [(n, p) for n, p in self.diffusion_model.named_parameters() if p.requires_grad]
            frozens = [(n, p) for n, p in self.diffusion_model.named_parameters() if not p.requires_grad]

            os.makedirs(self.save_folder, exist_ok=True)
            out_txt = os.path.join(self.save_folder, "trainable_params.txt")
            with open(out_txt, "w") as f:
                f.write("=== Trainable ===\n")
                for n, p in trainables:
                    f.write(_format_param(n, p) + "\n")
                f.write("\n=== Frozen ===\n")
                for n, p in frozens:
                    f.write(_format_param(n, p) + "\n")
            logger.info("Wrote detailed parameter list to %s", out_txt)

        self.state.learning_rate = float(getattr(self.args, "lr", 3e-5))
        params_to_optimize = [{"params": trainable_params, "lr": self.state.learning_rate}]
        self.optimizer = get_optimizer(
            params_to_optimize=params_to_optimize,
            optimizer_name=self.args.optimizer,
            learning_rate=self.state.learning_rate,
            beta1=float(getattr(self.args, "beta1", 0.9)),
            beta2=float(getattr(self.args, "beta2", 0.95)),
            beta3=float(getattr(self.args, "beta3", 0.999)),
            epsilon=float(getattr(self.args, "epsilon", 1e-8)),
            weight_decay=float(getattr(self.args, "weight_decay", 1e-5)),
            use_8bit=getattr(self.args, "optimizer_8bit", False),
            use_torchao=getattr(self.args, "optimizer_torchao", False),
        )

        dataset_size = len(self.train_dataset)
        per_device_bs = self.cfg.dataloader.params.batch_size
        world_size = self.state.accelerator.num_processes
        grad_accum = self.cfg.gradient_accumulation_steps

        num_upd_per_epoch = math.ceil(dataset_size / (per_device_bs * world_size * grad_accum))
        self.state.num_updates_per_epoch = num_upd_per_epoch

        if self.state.train_steps is None:
            self.state.train_steps = self.args.train_steps or (self.args.train_epochs * num_upd_per_epoch)
            self.state.overwrote_max_train_steps = True
        self.state.train_epochs = self.args.train_epochs

        num_training_steps = int(self.state.train_steps)
        num_warmup_steps = int(self.args.lr_warmup_steps)

        self.lr_scheduler = get_scheduler(
            name=self.args.lr_scheduler,
            optimizer=self.optimizer,
            num_warmup_steps=num_warmup_steps,
            num_training_steps=num_training_steps,
            num_cycles=1,
            power=1.0,
        )

        self.ema = None
        self._ema_params = None
        if self.use_ema:
            base_model = unwrap_model(self.state.accelerator, self.diffusion_model)
            self._ema_params = [p for p in base_model.parameters() if p.requires_grad]
            self.ema = EMAModel(
                parameters=self._ema_params,
                decay=self.ema_decay,
                min_decay=self.ema_min_decay,
                update_after_step=self.ema_update_after_step,
                use_ema_warmup=True,
                inv_gamma=self.ema_inv_gamma,
                power=self.ema_power,
            )
            try:
                self.ema.to(self.state.accelerator.device)
            except Exception:
                pass


@hydra.main(config_path=CONFIG_PATH, config_name=CONFIG_NAME, version_base=None)
def main(cfg: DictConfig):
    config_file = cfg.agent.get("config_file", DEFAULT_CONFIG_FILE)
    trainer = TwoStageVideoDriveTrainer(cfg, config_file)
    trainer.prepare_dataset()
    trainer.prepare_val_dataset()
    trainer.prepare_models()
    trainer.prepare_trainable_parameters()
    trainer.prepare_for_training()
    trainer.load_resume_state_if_needed()
    trainer.prepare_trackers()
    trainer.train()


if __name__ == "__main__":
    main()
