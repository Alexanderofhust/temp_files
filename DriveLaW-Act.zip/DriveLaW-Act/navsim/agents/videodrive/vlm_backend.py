from .cosmos_reason_vlm import (
    DEFAULT_SYSTEM_PROMPT,
    CosmosReasonBackbone,
    build_cosmos_coc_generation_prompt,
    build_cosmos_context_prompt,
    sanitize_cosmos_official_av_output,
)

import torch

from .utils.conversation import get_conv_template
from .utils.internvl_preprocess import load_image
from .utils.utils import format_number

try:
    from transformers import AutoModel, AutoTokenizer
except ImportError as exc:
    AutoModel = None
    AutoTokenizer = None
    _INTERNVL_IMPORT_ERROR = exc
else:
    _INTERNVL_IMPORT_ERROR = None

try:
    from transformers import AutoProcessor, Qwen3_5ForConditionalGeneration
except ImportError as exc:
    AutoProcessor = None
    Qwen3_5ForConditionalGeneration = None
    _QWEN35_IMPORT_ERROR = exc
else:
    _QWEN35_IMPORT_ERROR = None


DEFAULT_VLM_SYSTEM_PROMPT = DEFAULT_SYSTEM_PROMPT
OnlineVLMBackbone = CosmosReasonBackbone
build_vlm_coc_generation_prompt = build_cosmos_coc_generation_prompt
build_vlm_context_prompt = build_cosmos_context_prompt
sanitize_vlm_official_av_output = sanitize_cosmos_official_av_output

COSMOS_REASON_SYSTEM_PROMPT = (
    "You are a specialized agent for visual scene understanding in autonomous driving. "
    "Analyze the provided front-view image and ego-motion context to infer the ego vehicle's "
    "driving behavior. Follow the driving-decision rules in the user prompt. Output one "
    "concise factual sentence only."
)
QWEN35_SYSTEM_PROMPT = "You are a helpful autonomous driving assistant."

INTERNVL_SYSTEM_MESSAGE = """
You are a vehicle trajectory prediction model for autonomous driving. Your task is to predict the ego vehicle's 4-second trajectory based on the following inputs: multi-view images from 8 cameras, ego vehicle states (position), and discrete navigation commands. The input provides a 2-second history, and your output should ensure a safe trajectory for the next 4 seconds. Your predictions must adhere to the following metrics:
1. **No at-fault Collisions (NC)**: Avoid collisions with other objects/vehicles.
2. **Drivable Area Compliance (DAC)**: Stay within the drivable area.
3. **Time to Collision (TTC)**: Maintain a safe distance from other vehicles.
4. **Ego Progress (EP)**: Ensure the ego vehicle moves forward without being stuck.
5. **Comfort (C)**: Avoid sharp turns and sudden decelerations.
6. **Driving Direction Compliance (DDC)**: Align with the intended driving direction.
For evaluation, use the **PDM Score**, which combines these metrics: **PDM Score** = NC * DAC * (5*TTC + 5*EP + 2*C + 0*DDC) / 12.
Your predictions will be evaluated through a non-reactive 4-second simulation with an LQR controller and background actors following their recorded trajectories. The better your predictions, the higher your score.
"""

IMG_CONTEXT_TOKEN = "<IMG_CONTEXT>"
IMG_START_TOKEN = "<img>"
IMG_END_TOKEN = "</img>"


def _as_bool(value):
    if isinstance(value, str):
        return value.strip().lower() in ("1", "true", "yes", "y")
    return bool(value)


def _resolve_torch_dtype(dtype):
    if isinstance(dtype, torch.dtype):
        return dtype

    normalized = str(dtype).lower()
    if normalized == "auto":
        return "auto"

    dtype_map = {
        "float16": torch.float16,
        "fp16": torch.float16,
        "half": torch.float16,
        "bfloat16": torch.bfloat16,
        "bf16": torch.bfloat16,
        "float32": torch.float32,
        "fp32": torch.float32,
    }
    if normalized not in dtype_map:
        raise ValueError(f"Unsupported Qwen3.5 dtype: {dtype!r}")
    return dtype_map[normalized]


def _move_inputs_to_device(inputs, device):
    if hasattr(inputs, "to"):
        return inputs.to(device)
    return {
        key: value.to(device) if hasattr(value, "to") else value
        for key, value in inputs.items()
    }


def _format_qwen35_number(value, decimal_places: int = 2) -> str:
    rounded = round(float(value), decimal_places)
    if abs(rounded) <= 1e-2:
        return "0.0"
    return f"{rounded:.{decimal_places}f}"


def _qwen35_command_string(ego_statuses) -> str:
    high_command_one_hot = ego_statuses[-1].driving_command
    navigation_commands = ["turn left", "go straight", "turn right"]

    for idx in range(min(len(high_command_one_hot), len(navigation_commands))):
        cmd_value = high_command_one_hot[idx]
        if hasattr(cmd_value, "item"):
            cmd_value = cmd_value.item()
        if int(cmd_value) == 1:
            return navigation_commands[idx]
    return "unknown"


def build_qwen35_trajectory_prompt(ego_statuses) -> str:
    history_trajectory = []
    for idx in range(4):
        ego_pose = ego_statuses[idx].ego_pose
        history_trajectory.append(
            {
                "x": _format_qwen35_number(ego_pose[0]),
                "y": _format_qwen35_number(ego_pose[1]),
                "heading": _format_qwen35_number(ego_pose[2]),
            }
        )

    history_context = " ".join(
        [
            f'- t-{3 - idx}: ({pose["x"]}, {pose["y"]}, {pose["heading"]})'
            for idx, pose in enumerate(history_trajectory)
        ]
    )
    command_str = _qwen35_command_string(ego_statuses)

    return (
        "As an autonomous driving system, predict the vehicle's trajectory based on:\n"
        "1. Visual perception from front camera view\n"
        "2. Historical motion context (last 4 timesteps): "
        f"{history_context}\n"
        f"3. Active navigation command: [{command_str.upper()}]\n"
        "Output requirements:\n"
        "- Predict 8 future trajectory points\n"
        "- Each point format: (x:float, y:float, heading:float)\n"
        "- Use [PT, ...] to encapsulate the trajectory\n"
        "- Maintain numerical precision to 2 decimal places"
    )


def build_internvl_trajectory_prompt(ego_statuses) -> str:
    history_trajectory = []
    for idx in range(4):
        ego_pose = ego_statuses[idx].ego_pose
        history_trajectory.append(
            {
                "x": format_number(ego_pose[0]),
                "y": format_number(ego_pose[1]),
                "heading": format_number(ego_pose[2]),
            }
        )

    high_command_one_hot = ego_statuses[-1].driving_command
    navigation_commands = ["turn left", "go straight", "turn right"]
    command_str = next(
        (navigation_commands[i] for i, value in enumerate(high_command_one_hot) if int(value) == 1),
        "unknown",
    )
    history_str = " ".join(
        [
            f'   - t-{3 - i}: ({pose["x"]}, {pose["y"]}, {pose["heading"]})'
            for i, pose in enumerate(history_trajectory)
        ]
    )

    prompt = (
        "<image>\n"
        "As an autonomous driving system, predict the vehicle's trajectory based on:\n"
        "1. Visual perception from front camera view\n"
        f"2. Historical motion context (last 4 timesteps):{history_str}\n"
        f"3. Active navigation command: [{command_str.upper()}]"
    )
    output_requirements = (
        "\nOutput requirements:\n"
        "- Predict 8 future trajectory points\n"
        "- Each point format: (x:float, y:float, heading:float)\n"
        "- Use [PT, ...] to encapsulate the trajectory\n"
        "- Maintain numerical precision to 2 decimal places"
    )
    return f"{prompt}{output_requirements}"


class InternVLBackbone:
    def __init__(self, model_path: str, device: str = "cuda"):
        if AutoModel is None or AutoTokenizer is None:
            raise ImportError("InternVL direct_forward requires transformers AutoModel/AutoTokenizer.") from _INTERNVL_IMPORT_ERROR
        if not model_path:
            raise ValueError("model_path is required for InternVL direct_forward.")

        self.device = str(device)
        self.model = AutoModel.from_pretrained(
            model_path,
            torch_dtype=torch.bfloat16,
            low_cpu_mem_usage=True,
            trust_remote_code=True,
            use_flash_attn=True,
            device_map=self.device,
        ).eval()
        self.tokenizer = AutoTokenizer.from_pretrained(
            model_path,
            trust_remote_code=True,
            use_fast=False,
        )
        self.model.system_message = INTERNVL_SYSTEM_MESSAGE
        self.img_context_token_id = self.tokenizer.convert_tokens_to_ids(IMG_CONTEXT_TOKEN)
        self.model.img_context_token_id = self.img_context_token_id
        self.num_image_token = 256

    @torch.inference_mode()
    def direct_forward(self, image_path: str, prompt: str):
        pixel_values = load_image(str(image_path), max_num=12).unsqueeze(0)
        pixel_values_squeezed = pixel_values.squeeze(1)
        num_patches_list = [pv.shape[0] for pv in pixel_values_squeezed]
        pixel_values_cat = torch.cat(list(pixel_values_squeezed), dim=0)

        queries = []
        for idx, num_patches in enumerate(num_patches_list):
            question = prompt
            if pixel_values_cat is not None and "<image>" not in question:
                question = "<image>\n" + question

            template = get_conv_template("internvl2_5")
            template.system_message = INTERNVL_SYSTEM_MESSAGE
            template.append_message(template.roles[0], question)
            template.append_message(template.roles[1], None)
            query = template.get_prompt()

            image_tokens = IMG_START_TOKEN + IMG_CONTEXT_TOKEN * self.num_image_token * num_patches + IMG_END_TOKEN
            query = query.replace("<image>", image_tokens, 1)
            queries.append(query)

        self.tokenizer.padding_side = "left"
        model_inputs = self.tokenizer(queries, return_tensors="pt", padding="max_length", max_length=2800)
        device = torch.device(self.device)
        input_ids = model_inputs["input_ids"].to(device)
        attention_mask = model_inputs["attention_mask"].to(device)

        position_ids = attention_mask.long().cumsum(-1) - 1
        position_ids.masked_fill_(attention_mask == 0, 1)
        image_flags = torch.tensor([1] * pixel_values_cat.size(0), dtype=torch.long, device=device)

        outputs = self.model(
            pixel_values=pixel_values_cat.to(device=device, dtype=torch.bfloat16),
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            image_flags=image_flags.squeeze(-1),
            output_hidden_states=True,
            return_dict=True,
        )
        return outputs, {"attention_mask": attention_mask}


class Qwen35Backbone:
    def __init__(
        self,
        model_path: str,
        device: str = "cuda",
        model_dtype="float16",
        trust_remote_code: bool = True,
        attn_implementation=None,
        system_prompt: str = QWEN35_SYSTEM_PROMPT,
    ):
        if AutoProcessor is None or Qwen3_5ForConditionalGeneration is None:
            raise ImportError(
                "Qwen3.5 direct_forward requires a transformers build with "
                "Qwen3_5ForConditionalGeneration support."
            ) from _QWEN35_IMPORT_ERROR
        if not model_path:
            raise ValueError("model_path is required for Qwen3.5 direct_forward.")

        self.device = torch.device(device)
        self.system_prompt = system_prompt
        self.processor = AutoProcessor.from_pretrained(
            model_path,
            trust_remote_code=_as_bool(trust_remote_code),
        )
        self.model = self._load_model(
            model_path=model_path,
            model_dtype=model_dtype,
            trust_remote_code=trust_remote_code,
            attn_implementation=attn_implementation,
        )
        self.model = self.model.to(self.device).eval()

    def _load_model(
        self,
        model_path: str,
        model_dtype,
        trust_remote_code: bool,
        attn_implementation,
    ):
        resolved_dtype = _resolve_torch_dtype(model_dtype)
        model_kwargs = {"trust_remote_code": _as_bool(trust_remote_code)}

        if resolved_dtype != "auto":
            model_kwargs["torch_dtype"] = resolved_dtype
        else:
            model_kwargs["torch_dtype"] = "auto"
        if attn_implementation:
            model_kwargs["attn_implementation"] = attn_implementation

        try:
            return Qwen3_5ForConditionalGeneration.from_pretrained(model_path, **model_kwargs)
        except TypeError:
            if "torch_dtype" in model_kwargs:
                model_kwargs["dtype"] = model_kwargs.pop("torch_dtype")
            return Qwen3_5ForConditionalGeneration.from_pretrained(model_path, **model_kwargs)

    def _build_messages(self, image_path: str, prompt: str):
        return [
            {
                "role": "system",
                "content": [{"type": "text", "text": self.system_prompt}],
            },
            {
                "role": "user",
                "content": [
                    {"type": "image", "image": image_path},
                    {"type": "text", "text": "\n" + prompt},
                ],
            },
        ]

    def direct_forward(self, image_path: str, prompt: str):
        messages = self._build_messages(image_path=image_path, prompt=prompt)
        inputs = self.processor.apply_chat_template(
            messages,
            tokenize=True,
            add_generation_prompt=True,
            return_dict=True,
            return_tensors="pt",
        )
        inputs = _move_inputs_to_device(inputs, self.device)

        with torch.inference_mode():
            outputs = self.model(
                **inputs,
                output_hidden_states=True,
                return_dict=True,
                use_cache=False,
            )
        return outputs, inputs
