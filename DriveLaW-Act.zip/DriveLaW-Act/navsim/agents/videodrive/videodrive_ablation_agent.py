from typing import Optional

from .videodrive_agent import VideoDriveAgent


class VideoDriveAblationAgent(VideoDriveAgent):
    """VideoDrive agent variant for isolated PDM ablation evaluation."""

    _VALID_ABLATION_MODES = {"none", "zero", "noise"}

    def __init__(
        self,
        diffusion_model_path: Optional[str] = "",
        vlm_hidden_ablation: str = "none",
        video_context_ablation: str = "none",
        ablation_noise_seed: int = 42,
        ablation_noise_scale: float = 1.0,
        **kwargs,
    ):
        super().__init__(**kwargs)
        if diffusion_model_path:
            self.args.diffusion_model["model_path"] = str(diffusion_model_path)

        self.vlm_hidden_ablation = self._normalize_ablation_mode(
            vlm_hidden_ablation,
            "vlm_hidden_ablation",
        )
        self.video_context_ablation = self._normalize_ablation_mode(
            video_context_ablation,
            "video_context_ablation",
        )
        self.ablation_noise_seed = int(ablation_noise_seed)
        self.ablation_noise_scale = float(ablation_noise_scale)

    @classmethod
    def _normalize_ablation_mode(cls, value: Optional[str], name: str) -> str:
        mode = str(value or "none").strip().lower()
        if mode not in cls._VALID_ABLATION_MODES:
            raise ValueError(f"{name} must be one of {sorted(cls._VALID_ABLATION_MODES)}, got {value!r}")
        return mode

    def initialize(self) -> None:
        super().initialize()
        if not hasattr(self.pipe, "set_ablation_config"):
            raise RuntimeError(
                "VideoDriveAblationAgent requires an ablation pipeline. "
                "Please use video_model_infer_navsim_eval_ablation.yaml."
            )

        self.pipe.set_ablation_config(
            vlm_hidden_ablation=self.vlm_hidden_ablation,
            video_context_ablation=self.video_context_ablation,
            ablation_noise_seed=self.ablation_noise_seed,
            ablation_noise_scale=self.ablation_noise_scale,
        )
        print(
            "[VideoDriveAblationAgent] Ablation config: "
            f"vlm_hidden_ablation={self.vlm_hidden_ablation}, "
            f"video_context_ablation={self.video_context_ablation}, "
            f"ablation_noise_seed={self.ablation_noise_seed}, "
            f"ablation_noise_scale={self.ablation_noise_scale}"
        )
