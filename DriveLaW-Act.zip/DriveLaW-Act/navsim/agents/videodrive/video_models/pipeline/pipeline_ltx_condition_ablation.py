from typing import Optional

import torch
from diffusers.utils.torch_utils import randn_tensor

from navsim.agents.videodrive.video_models.pipeline.pipeline_ltx_condition import LTXConditionPipeline


class LTXConditionAblationPipeline(LTXConditionPipeline):
    """Ablation-only pipeline variant for VideoDrive PDM evaluation.

    This class intentionally keeps the original LTXConditionPipeline untouched.
    It only intercepts the tensors requested by the ablation evaluation entry.
    """

    _VALID_ABLATION_MODES = {"none", "zero", "noise"}

    def set_ablation_config(
        self,
        vlm_hidden_ablation: str = "none",
        video_context_ablation: str = "none",
        ablation_noise_seed: int = 42,
        ablation_noise_scale: float = 1.0,
    ) -> None:
        self.vlm_hidden_ablation = self._normalize_ablation_mode(vlm_hidden_ablation, "vlm_hidden_ablation")
        self.video_context_ablation = self._normalize_ablation_mode(
            video_context_ablation,
            "video_context_ablation",
        )
        self.ablation_noise_seed = int(ablation_noise_seed)
        self.ablation_noise_scale = float(ablation_noise_scale)

    @classmethod
    def _normalize_ablation_mode(cls, value: Optional[str], name: str) -> str:
        mode = str(value or "none").strip().lower()
        if mode not in cls._VALID_ABLATION_MODES:
            raise ValueError(f"{name} must be one of {sorted(cls._VALID_ABLATION_MODES)}, got {value!r}")
        return mode

    def _ablation_mode(self, attr: str) -> str:
        return self._normalize_ablation_mode(getattr(self, attr, "none"), attr)

    def _make_ablation_generator(self, device: torch.device) -> torch.Generator:
        try:
            generator = torch.Generator(device=device)
        except (RuntimeError, ValueError, TypeError):
            generator = torch.Generator()
        generator.manual_seed(int(getattr(self, "ablation_noise_seed", 42)))
        return generator

    def _ablate_tensor(
        self,
        tensor: torch.Tensor,
        mode: str,
        generator: Optional[torch.Generator] = None,
        mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        if mode == "none" or tensor is None:
            return tensor

        if mode == "zero":
            replacement = torch.zeros_like(tensor)
        elif mode == "noise":
            if generator is None:
                generator = self._make_ablation_generator(tensor.device)
            replacement = randn_tensor(
                tensor.shape,
                generator=generator,
                device=tensor.device,
                dtype=tensor.dtype,
            )
            replacement = replacement * float(getattr(self, "ablation_noise_scale", 1.0))
        else:
            raise ValueError(f"Unsupported ablation mode: {mode}")

        if mask is None:
            return replacement

        mask = mask.to(device=tensor.device, dtype=torch.bool)
        while mask.ndim < tensor.ndim:
            mask = mask.unsqueeze(-1)
        return torch.where(mask, replacement, tensor)

    @staticmethod
    def _future_token_mask_from_timestep(
        timestep: Optional[torch.Tensor],
        batch_size: int,
        seq_len: int,
    ) -> Optional[torch.Tensor]:
        if timestep is None:
            return None

        if timestep.ndim == 1:
            timestep = timestep.unsqueeze(0)
        elif timestep.ndim > 2:
            timestep = timestep.reshape(timestep.shape[0], -1)

        if timestep.shape[-1] != seq_len:
            raise ValueError(
                "Cannot derive video future-token mask: "
                f"timestep length {timestep.shape[-1]} != video buffer length {seq_len}"
            )

        if timestep.shape[0] != batch_size:
            if batch_size % timestep.shape[0] != 0:
                raise ValueError(
                    "Cannot align video future-token mask: "
                    f"mask batch {timestep.shape[0]} vs buffer batch {batch_size}"
                )
            repeat = batch_size // timestep.shape[0]
            timestep = timestep.repeat_interleave(repeat, dim=0)

        return timestep > 0

    def _ablate_video_states_buffer(
        self,
        video_states_buffer,
        timestep: Optional[torch.Tensor],
    ):
        mode = self._ablation_mode("video_context_ablation")
        if mode == "none" or video_states_buffer is None:
            return video_states_buffer

        generator = None
        ablated_buffer = []
        for states in video_states_buffer:
            if states is None:
                ablated_buffer.append(states)
                continue
            future_mask = self._future_token_mask_from_timestep(
                timestep,
                batch_size=states.shape[0],
                seq_len=states.shape[1],
            )
            if generator is None:
                generator = self._make_ablation_generator(states.device)
            ablated_buffer.append(self._ablate_tensor(states, mode, generator=generator, mask=future_mask))
        return ablated_buffer

    def _ablate_vlm_hidden_states(self, vlm_hidden_states: Optional[torch.Tensor]) -> Optional[torch.Tensor]:
        mode = self._ablation_mode("vlm_hidden_ablation")
        if mode == "none" or vlm_hidden_states is None:
            return vlm_hidden_states
        generator = self._make_ablation_generator(vlm_hidden_states.device)
        return self._ablate_tensor(vlm_hidden_states, mode, generator=generator)

    @torch.no_grad()
    def infer(self, *args, vlm_hidden_states: Optional[torch.Tensor] = None, **kwargs):
        vlm_hidden_states = self._ablate_vlm_hidden_states(vlm_hidden_states)

        if self._ablation_mode("video_context_ablation") == "none":
            return super().infer(*args, vlm_hidden_states=vlm_hidden_states, **kwargs)

        original_forward = self.transformer.forward

        def wrapped_forward(*forward_args, **forward_kwargs):
            result = original_forward(*forward_args, **forward_kwargs)
            store_buffer = bool(forward_kwargs.get("store_buffer", False))
            if not store_buffer:
                return result

            if not isinstance(result, tuple) or not result:
                return result
            payload = result[0]
            if not isinstance(payload, dict) or "video_states_buffer" not in payload:
                return result

            payload["video_states_buffer"] = self._ablate_video_states_buffer(
                payload["video_states_buffer"],
                forward_kwargs.get("timestep"),
            )
            return result

        self.transformer.forward = wrapped_forward
        try:
            return super().infer(*args, vlm_hidden_states=vlm_hidden_states, **kwargs)
        finally:
            self.transformer.forward = original_forward
