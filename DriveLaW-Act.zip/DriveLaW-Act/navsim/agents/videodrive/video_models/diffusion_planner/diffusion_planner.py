import math
from typing import Any, Dict, Optional, Tuple


import torch
import torch.nn as nn

from diffusers.models.attention import FeedForward
from diffusers.models.normalization import AdaLayerNormSingle, RMSNorm
from diffusers.utils.torch_utils import maybe_allow_in_graph
from diffusers.models.attention import Attention

from timm.models.layers import Mlp
from .blocks.encoder import (
    StateAttentionEncoder,
    SwiGLUFFN,
)
from diffusers.utils import USE_PEFT_BACKEND, deprecate, is_torch_version
from diffusers.models.attention_dispatch import dispatch_attention_fn


class VLMQueryResampler(nn.Module):
    def __init__(
        self,
        input_dim: int = 1536,
        output_dim: int = 2048,
        num_queries: int = 32,
        num_heads: int = 16,
        depth: int = 2,
        ffn_mult: int = 4,
    ):
        super().__init__()
        self.input_proj = nn.Linear(input_dim, output_dim)

        self.query_tokens = nn.Parameter(
            torch.randn(1, num_queries, output_dim) * 0.02
        )

        self.layers = nn.ModuleList([
            nn.ModuleDict({
                "norm_q": nn.LayerNorm(output_dim),
                "norm_kv": nn.LayerNorm(output_dim),
                "attn": nn.MultiheadAttention(
                    embed_dim=output_dim,
                    num_heads=num_heads,
                    batch_first=True,
                ),
                "ffn": nn.Sequential(
                    nn.LayerNorm(output_dim),
                    nn.Linear(output_dim, output_dim * ffn_mult),
                    nn.GELU(),
                    nn.Linear(output_dim * ffn_mult, output_dim),
                ),
            })
            for _ in range(depth)
        ])

        self.out_norm = nn.LayerNorm(output_dim)

    def forward(self, vlm_tokens, vlm_attention_mask=None):
        B = vlm_tokens.shape[0]

        kv = self.input_proj(vlm_tokens)
        q = self.query_tokens.expand(B, -1, -1)

        key_padding_mask = None
        if vlm_attention_mask is not None:
            vlm_attention_mask = vlm_attention_mask.bool()

            empty_mask = vlm_attention_mask.sum(dim=1) == 0
            if empty_mask.any():
                vlm_attention_mask = vlm_attention_mask.clone()
                vlm_attention_mask[empty_mask, 0] = True

            key_padding_mask = ~vlm_attention_mask

        for layer in self.layers:
            q_norm = layer["norm_q"](q)
            kv_norm = layer["norm_kv"](kv)

            attn_out, _ = layer["attn"](
                query=q_norm,
                key=kv_norm,
                value=kv_norm,
                key_padding_mask=key_padding_mask,
                need_weights=False,
            )

            q = q + attn_out
            q = q + layer["ffn"](q)

        return self.out_norm(q)


class VLMFeatureProjector(nn.Module):
    def __init__(
        self,
        input_dim: int = 1536,
        output_dim: int = 512,
    ):
        super().__init__()
        self.net = nn.Sequential(
            nn.LayerNorm(input_dim),
            nn.Linear(input_dim, output_dim),
            nn.GELU(),
            nn.Linear(output_dim, output_dim),
            nn.LayerNorm(output_dim),
        )

    def forward(self, vlm_tokens: torch.Tensor) -> torch.Tensor:
        return self.net(vlm_tokens)


class VideoConditionedVLMAdapter(nn.Module):
    def __init__(
        self,
        video_dim: int = 2048,
        dim: int = 512,
        video_pool_tokens: int = 64,
        vlm_queries: int = 32,
        heads: int = 16,
        ffn_mult: int = 4,
    ):
        super().__init__()
        if video_pool_tokens <= 0:
            raise ValueError("video_pool_tokens must be positive.")
        if vlm_queries <= 0:
            raise ValueError("vlm_queries must be positive.")

        self.video_proj = nn.Sequential(
            nn.LayerNorm(video_dim),
            nn.Linear(video_dim, dim),
            nn.GELU(),
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
        )
        self.video_queries = nn.Parameter(torch.randn(1, video_pool_tokens, dim) * 0.02)
        self.vlm_queries = nn.Parameter(torch.randn(1, vlm_queries, dim) * 0.02)

        self.norm_video_q = nn.LayerNorm(dim)
        self.norm_video_kv = nn.LayerNorm(dim)
        self.video_pool_attn = nn.MultiheadAttention(
            embed_dim=dim,
            num_heads=heads,
            batch_first=True,
        )

        self.norm_query = nn.LayerNorm(dim)
        self.norm_video_summary = nn.LayerNorm(dim)
        self.read_video_attn = nn.MultiheadAttention(
            embed_dim=dim,
            num_heads=heads,
            batch_first=True,
        )

        self.norm_vlm_query = nn.LayerNorm(dim)
        self.norm_vlm_kv = nn.LayerNorm(dim)
        self.read_vlm_attn = nn.MultiheadAttention(
            embed_dim=dim,
            num_heads=heads,
            batch_first=True,
        )

        self.ffn = nn.Sequential(
            nn.LayerNorm(dim),
            nn.Linear(dim, dim * ffn_mult),
            nn.GELU(),
            nn.Linear(dim * ffn_mult, dim),
        )
        self.out_norm = nn.LayerNorm(dim)

    def forward(
        self,
        video_tokens: torch.Tensor,
        base_vlm_tokens: torch.Tensor,
        vlm_attention_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        batch_size = base_vlm_tokens.shape[0]
        video_tokens = video_tokens.to(
            device=base_vlm_tokens.device,
            dtype=base_vlm_tokens.dtype,
        ).detach()

        video_kv = self.video_proj(video_tokens)
        video_queries = self.video_queries.expand(batch_size, -1, -1)
        video_summary_delta, _ = self.video_pool_attn(
            query=self.norm_video_q(video_queries),
            key=self.norm_video_kv(video_kv),
            value=video_kv,
            need_weights=False,
        )
        video_summary = video_queries + video_summary_delta

        queries = self.vlm_queries.expand(batch_size, -1, -1)
        video_context, _ = self.read_video_attn(
            query=self.norm_query(queries),
            key=self.norm_video_summary(video_summary),
            value=video_summary,
            need_weights=False,
        )
        conditioned_queries = queries + video_context

        key_padding_mask = None
        if vlm_attention_mask is not None:
            vlm_attention_mask = vlm_attention_mask.to(
                device=base_vlm_tokens.device,
                dtype=torch.bool,
            )
            empty_mask = vlm_attention_mask.sum(dim=1) == 0
            if empty_mask.any():
                vlm_attention_mask = vlm_attention_mask.clone()
                vlm_attention_mask[empty_mask, 0] = True
            key_padding_mask = ~vlm_attention_mask

        refined_delta, _ = self.read_vlm_attn(
            query=self.norm_vlm_query(conditioned_queries),
            key=self.norm_vlm_kv(base_vlm_tokens),
            value=base_vlm_tokens,
            key_padding_mask=key_padding_mask,
            need_weights=False,
        )
        refined = conditioned_queries + refined_delta
        refined = refined + self.ffn(refined)
        return self.out_norm(refined)


class MaskedJointVLMBlock(nn.Module):
    def __init__(
        self,
        video_dim: int = 2048,
        vlm_dim: int = 512,
        action_dim: int = 512,
        joint_dim: int = 2048,
        eps: float = 1e-6,
        attention_bias: bool = True,
        attention_out_bias: bool = True,
        video_attend_vlm: bool = False,
    ):
        super().__init__()
        self.video_dim = video_dim
        self.vlm_dim = vlm_dim
        self.action_dim = action_dim
        self.joint_dim = joint_dim
        self.video_attend_vlm = video_attend_vlm

        qk_norm_eps = 1e-5
        self.action_to_q = nn.Linear(action_dim, joint_dim, bias=attention_bias)
        self.action_to_k = nn.Linear(action_dim, joint_dim, bias=attention_bias)
        self.action_to_v = nn.Linear(action_dim, joint_dim, bias=attention_bias)
        self.action_norm_q = nn.RMSNorm(joint_dim, eps=qk_norm_eps, elementwise_affine=True)
        self.action_norm_k = nn.RMSNorm(joint_dim, eps=qk_norm_eps, elementwise_affine=True)
        self.action_to_out = nn.Linear(joint_dim, action_dim, bias=attention_out_bias)

        self.vlm_norm1 = RMSNorm(vlm_dim, eps=eps, elementwise_affine=False)
        self.vlm_to_q = nn.Linear(vlm_dim, joint_dim, bias=attention_bias)
        self.vlm_to_k = nn.Linear(vlm_dim, joint_dim, bias=attention_bias)
        self.vlm_to_v = nn.Linear(vlm_dim, joint_dim, bias=attention_bias)
        self.vlm_norm_q = nn.RMSNorm(joint_dim, eps=qk_norm_eps, elementwise_affine=True)
        self.vlm_norm_k = nn.RMSNorm(joint_dim, eps=qk_norm_eps, elementwise_affine=True)
        self.vlm_to_out = nn.Linear(joint_dim, vlm_dim, bias=attention_out_bias)
        self.vlm_norm2 = RMSNorm(vlm_dim, eps=eps, elementwise_affine=False)
        self.vlm_ff = SwiGLUFFN(vlm_dim, bias=True)

    @staticmethod
    def _shape_heads(states: torch.Tensor, heads: int) -> torch.Tensor:
        return states.unflatten(2, (heads, -1))

    @staticmethod
    def _build_vlm_key_attention_mask(
        batch_size: int,
        heads: int,
        query_len: int,
        prefix_len: int,
        vlm_len: int,
        suffix_len: int,
        vlm_attention_mask: Optional[torch.Tensor],
        dtype: torch.dtype,
        device: torch.device,
    ) -> Optional[torch.Tensor]:
        if vlm_attention_mask is None:
            return None

        vlm_attention_mask = vlm_attention_mask.to(device=device, dtype=torch.bool)
        if vlm_attention_mask.shape[1] != vlm_len:
            raise ValueError(
                f"joint VLM attention mask length {vlm_attention_mask.shape[1]} "
                f"does not match VLM token length {vlm_len}"
            )

        key_len = prefix_len + vlm_len + suffix_len
        key_valid = torch.ones((batch_size, key_len), device=device, dtype=torch.bool)
        key_valid[:, prefix_len : prefix_len + vlm_len] = vlm_attention_mask

        attention_mask = torch.zeros((batch_size, 1, 1, key_len), device=device, dtype=dtype)
        attention_mask = attention_mask.masked_fill(~key_valid[:, None, None, :], -10000.0)
        return attention_mask.expand(-1, heads, query_len, -1).contiguous()

    @staticmethod
    def _video_ada_values(video_block, hidden_states: torch.Tensor, temb: torch.Tensor):
        batch_size = hidden_states.size(0)
        num_ada_params = video_block.scale_shift_table.shape[0]
        ada_values = video_block.scale_shift_table[None, None].to(
            device=temb.device,
            dtype=temb.dtype,
        ) + temb.reshape(batch_size, temb.size(1), num_ada_params, -1)
        return ada_values.unbind(dim=2)

    @staticmethod
    def _action_ada_values(action_block, hidden_states: torch.Tensor, temb: torch.Tensor):
        batch_size, action_len, action_dim = hidden_states.shape
        num_ada_params = action_block.scale_shift_table.shape[0]
        table = action_block.scale_shift_table[None, None].to(device=temb.device, dtype=temb.dtype)

        if temb.shape[-1] == action_dim * num_ada_params:
            ada_values = table + temb.view(batch_size, action_len, num_ada_params, action_dim)
        elif temb.shape[-1] == action_dim:
            ada_core = temb.unsqueeze(2).expand(batch_size, action_len, num_ada_params, action_dim)
            ada_values = table + ada_core
        else:
            raise ValueError(
                f"temb last dim {temb.shape[-1]} not in "
                f"{{D, {num_ada_params}*D}} with D={action_dim}"
            )

        return ada_values.unbind(dim=2)

    def forward(
        self,
        video_block,
        action_block,
        video_hidden_states: torch.Tensor,
        vlm_hidden_states: torch.Tensor,
        action_hidden_states: torch.Tensor,
        video_temb: Optional[torch.Tensor],
        action_temb: torch.Tensor,
        image_rotary_emb: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
        action_rotary_emb: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
        encoder_hidden_states: Optional[torch.Tensor] = None,
        encoder_attention_mask: Optional[torch.Tensor] = None,
        vlm_attention_mask: Optional[torch.Tensor] = None,
        update_video: bool = True,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        if video_hidden_states.shape[0] != action_hidden_states.shape[0]:
            raise ValueError("joint attention requires video and action batch sizes to match.")
        if vlm_hidden_states.shape[0] != action_hidden_states.shape[0]:
            raise ValueError("joint attention requires VLM and action batch sizes to match.")

        video_attn = video_block.attn1
        heads = video_attn.heads
        if self.joint_dim != video_attn.inner_dim:
            raise ValueError(
                f"joint_dim {self.joint_dim} must match video attention inner_dim {video_attn.inner_dim}"
            )

        video_shift_msa, video_scale_msa, video_gate_msa, video_shift_mlp, video_scale_mlp, video_gate_mlp = (
            self._video_ada_values(video_block, video_hidden_states, video_temb)
        )
        action_shift_msa, action_scale_msa, action_gate_msa, action_shift_mlp, action_scale_mlp, action_gate_mlp = (
            self._action_ada_values(action_block, action_hidden_states, action_temb)
        )

        norm_video_states = video_block.norm1(video_hidden_states)
        norm_video_states = norm_video_states * (1 + video_scale_msa) + video_shift_msa

        norm_action_states = action_block.norm1(action_hidden_states)
        norm_action_states = norm_action_states * (1 + action_scale_msa) + action_shift_msa

        if vlm_attention_mask is not None:
            vlm_valid = vlm_attention_mask.to(device=vlm_hidden_states.device, dtype=vlm_hidden_states.dtype).unsqueeze(-1)
            vlm_hidden_states = vlm_hidden_states * vlm_valid
        else:
            vlm_valid = None
        norm_vlm_states = self.vlm_norm1(vlm_hidden_states)

        video_query = video_attn.norm_q(video_attn.to_q(norm_video_states))
        video_key = video_attn.norm_k(video_attn.to_k(norm_video_states))
        video_value = video_attn.to_v(norm_video_states)
        if image_rotary_emb is not None:
            video_query = apply_rotary_emb(video_query, image_rotary_emb)
            video_key = apply_rotary_emb(video_key, image_rotary_emb)

        action_query = self.action_norm_q(self.action_to_q(norm_action_states))
        action_key = self.action_norm_k(self.action_to_k(norm_action_states))
        action_value = self.action_to_v(norm_action_states)
        if action_rotary_emb is not None:
            action_query = apply_rotary_emb(action_query, action_rotary_emb)
            action_key = apply_rotary_emb(action_key, action_rotary_emb)

        vlm_query = self.vlm_norm_q(self.vlm_to_q(norm_vlm_states))
        vlm_key = self.vlm_norm_k(self.vlm_to_k(norm_vlm_states))
        vlm_value = self.vlm_to_v(norm_vlm_states)

        video_query = self._shape_heads(video_query, heads)
        video_key = self._shape_heads(video_key, heads)
        video_value = self._shape_heads(video_value, heads)
        vlm_query = self._shape_heads(vlm_query, heads)
        vlm_key = self._shape_heads(vlm_key, heads)
        vlm_value = self._shape_heads(vlm_value, heads)
        action_query = self._shape_heads(action_query, heads)
        action_key = self._shape_heads(action_key, heads)
        action_value = self._shape_heads(action_value, heads)

        video_len = video_hidden_states.shape[1]
        vlm_len = vlm_hidden_states.shape[1]
        action_len = action_hidden_states.shape[1]

        if update_video:
            if self.video_attend_vlm:
                video_key_states = torch.cat([video_key, vlm_key], dim=1)
                video_value_states = torch.cat([video_value, vlm_value], dim=1)
                video_attention_bias = self._build_vlm_key_attention_mask(
                    batch_size=action_hidden_states.shape[0],
                    heads=heads,
                    query_len=video_len,
                    prefix_len=video_len,
                    vlm_len=vlm_len,
                    suffix_len=0,
                    vlm_attention_mask=vlm_attention_mask,
                    dtype=video_query.dtype,
                    device=video_query.device,
                )
                video_joint = dispatch_attention_fn(
                    video_query,
                    video_key_states,
                    video_value_states,
                    attn_mask=video_attention_bias,
                    dropout_p=0.0,
                    is_causal=False,
                    backend=None,
                )
            else:
                video_joint = dispatch_attention_fn(
                    video_query,
                    video_key,
                    video_value,
                    attn_mask=None,
                    dropout_p=0.0,
                    is_causal=False,
                    backend=None,
                )
            video_joint = video_joint.flatten(2, 3).to(video_query.dtype)

        vlm_key_states = torch.cat([video_key, vlm_key], dim=1)
        vlm_value_states = torch.cat([video_value, vlm_value], dim=1)
        vlm_attention_bias = self._build_vlm_key_attention_mask(
            batch_size=action_hidden_states.shape[0],
            heads=heads,
            query_len=vlm_len,
            prefix_len=video_len,
            vlm_len=vlm_len,
            suffix_len=0,
            vlm_attention_mask=vlm_attention_mask,
            dtype=vlm_query.dtype,
            device=vlm_query.device,
        )
        vlm_joint = dispatch_attention_fn(
            vlm_query,
            vlm_key_states,
            vlm_value_states,
            attn_mask=vlm_attention_bias,
            dropout_p=0.0,
            is_causal=False,
            backend=None,
        )
        vlm_joint = vlm_joint.flatten(2, 3).to(vlm_query.dtype)

        action_key_states = torch.cat([video_key, vlm_key, action_key], dim=1)
        action_value_states = torch.cat([video_value, vlm_value, action_value], dim=1)
        action_attention_bias = self._build_vlm_key_attention_mask(
            batch_size=action_hidden_states.shape[0],
            heads=heads,
            query_len=action_len,
            prefix_len=video_len,
            vlm_len=vlm_len,
            suffix_len=action_len,
            vlm_attention_mask=vlm_attention_mask,
            dtype=action_query.dtype,
            device=action_query.device,
        )
        action_joint = dispatch_attention_fn(
            action_query,
            action_key_states,
            action_value_states,
            attn_mask=action_attention_bias,
            dropout_p=0.0,
            is_causal=False,
            backend=None,
        )
        action_joint = action_joint.flatten(2, 3).to(action_query.dtype)

        if update_video:
            video_delta = video_attn.to_out[0](video_joint)
            video_delta = video_attn.to_out[1](video_delta)
            video_hidden_states = video_hidden_states + video_delta * video_gate_msa

            video_cross_delta = video_block.attn2(
                video_hidden_states,
                encoder_hidden_states=encoder_hidden_states,
                image_rotary_emb=None,
                attention_mask=encoder_attention_mask,
            )
            video_hidden_states = video_hidden_states + video_cross_delta
            norm_video_states = video_block.norm2(video_hidden_states) * (1 + video_scale_mlp) + video_shift_mlp
            video_hidden_states = video_hidden_states + video_block.ff(norm_video_states) * video_gate_mlp

        action_delta = self.action_to_out(action_joint)
        action_hidden_states = action_hidden_states + action_delta * action_gate_msa
        norm_action_states = action_block.norm2(action_hidden_states) * (1 + action_scale_mlp) + action_shift_mlp
        action_hidden_states = action_hidden_states + action_block.ff(norm_action_states) * action_gate_mlp

        vlm_delta = self.vlm_to_out(vlm_joint)
        vlm_hidden_states = vlm_hidden_states + vlm_delta
        vlm_hidden_states = vlm_hidden_states + self.vlm_ff(self.vlm_norm2(vlm_hidden_states))
        if vlm_valid is not None:
            vlm_hidden_states = vlm_hidden_states * vlm_valid

        return video_hidden_states, vlm_hidden_states, action_hidden_states


def _as_bool(value) -> bool:
    if isinstance(value, str):
        return value.strip().lower() in ("1", "true", "yes", "y")
    return bool(value)


def masked_mean_tokens(tokens: torch.Tensor, attention_mask: Optional[torch.Tensor] = None) -> torch.Tensor:
    if attention_mask is None:
        return tokens.mean(dim=1)

    attention_mask = attention_mask.to(device=tokens.device, dtype=torch.bool)
    mask = attention_mask.unsqueeze(-1).to(tokens.dtype)
    denom = mask.sum(dim=1).clamp_min(1.0)
    return (tokens * mask).sum(dim=1) / denom


def prepare_action_vlm_states(self, vlm_hidden_states, vlm_attention_mask, action_hidden_states):
    if vlm_hidden_states is None:
        return None, vlm_attention_mask

    if (
        not hasattr(self, "action_vlm_proj")
        and not hasattr(self, "action_vlm_resampler")
        and not hasattr(self, "action_vlm_projector")
    ):
        return vlm_hidden_states, vlm_attention_mask

    if vlm_hidden_states.ndim == 2:
        vlm_hidden_states = vlm_hidden_states.unsqueeze(0)
    if vlm_attention_mask is not None and vlm_attention_mask.ndim == 1:
        vlm_attention_mask = vlm_attention_mask.unsqueeze(0)

    vlm_hidden_states = vlm_hidden_states.to(
        device=action_hidden_states.device,
        dtype=action_hidden_states.dtype,
    )
    if vlm_attention_mask is not None:
        vlm_attention_mask = vlm_attention_mask.to(
            device=action_hidden_states.device,
            dtype=torch.bool,
        )

    if vlm_hidden_states.shape[0] != action_hidden_states.shape[0]:
        assert action_hidden_states.shape[0] % vlm_hidden_states.shape[0] == 0, (
            "VLM hidden states batch size is not aligned with action batch size"
        )
        repeat = action_hidden_states.shape[0] // vlm_hidden_states.shape[0]
        vlm_hidden_states = vlm_hidden_states.repeat_interleave(repeat, dim=0)
        if vlm_attention_mask is not None:
            vlm_attention_mask = vlm_attention_mask.repeat_interleave(repeat, dim=0)

    if getattr(self, "action_vlm_adapter_mode", "global") == "video_conditioned":
        vlm_hidden_states = self.action_vlm_projector(vlm_hidden_states)
        if vlm_attention_mask is not None:
            vlm_hidden_states = vlm_hidden_states * vlm_attention_mask.unsqueeze(-1).to(vlm_hidden_states.dtype)
    elif hasattr(self, "action_vlm_resampler"):
        vlm_hidden_states = self.action_vlm_resampler(
            vlm_hidden_states,
            vlm_attention_mask,
        )
        vlm_attention_mask = torch.ones(
            vlm_hidden_states.shape[:2],
            device=vlm_hidden_states.device,
            dtype=torch.bool,
        )
    else:
        if vlm_attention_mask is not None:
            vlm_hidden_states = vlm_hidden_states * vlm_attention_mask.unsqueeze(-1).to(vlm_hidden_states.dtype)
        vlm_hidden_states = self.action_vlm_proj(vlm_hidden_states)
        if vlm_attention_mask is not None:
            vlm_hidden_states = vlm_hidden_states * vlm_attention_mask.unsqueeze(-1).to(vlm_hidden_states.dtype)

    return vlm_hidden_states, vlm_attention_mask


def prepare_joint_vlm_states(self, vlm_hidden_states, vlm_attention_mask, action_hidden_states):
    if vlm_hidden_states is None:
        raise ValueError("joint_vlm_enable=True requires vlm_hidden_states.")
    if not hasattr(self, "joint_vlm_projector") and not hasattr(self, "joint_vlm_resampler"):
        raise ValueError("joint_vlm_enable=True requires a joint VLM projector or resampler to be initialized.")

    if vlm_hidden_states.ndim == 2:
        vlm_hidden_states = vlm_hidden_states.unsqueeze(0)
    if vlm_attention_mask is not None and vlm_attention_mask.ndim == 1:
        vlm_attention_mask = vlm_attention_mask.unsqueeze(0)

    vlm_hidden_states = vlm_hidden_states.to(
        device=action_hidden_states.device,
        dtype=action_hidden_states.dtype,
    )
    if vlm_attention_mask is not None:
        vlm_attention_mask = vlm_attention_mask.to(
            device=action_hidden_states.device,
            dtype=torch.bool,
        )

    if vlm_hidden_states.shape[0] != action_hidden_states.shape[0]:
        assert action_hidden_states.shape[0] % vlm_hidden_states.shape[0] == 0, (
            "VLM hidden states batch size is not aligned with action batch size"
        )
        repeat = action_hidden_states.shape[0] // vlm_hidden_states.shape[0]
        vlm_hidden_states = vlm_hidden_states.repeat_interleave(repeat, dim=0)
        if vlm_attention_mask is not None:
            vlm_attention_mask = vlm_attention_mask.repeat_interleave(repeat, dim=0)

    if vlm_attention_mask is not None and bool(vlm_attention_mask.all().item()):
        vlm_attention_mask = None

    if hasattr(self, "joint_vlm_resampler"):
        vlm_hidden_states = self.joint_vlm_resampler(
            vlm_hidden_states,
            vlm_attention_mask,
        )
        return vlm_hidden_states, None

    if vlm_attention_mask is not None:
        vlm_hidden_states = vlm_hidden_states * vlm_attention_mask.unsqueeze(-1).to(vlm_hidden_states.dtype)
    vlm_hidden_states = self.joint_vlm_projector(vlm_hidden_states)
    if vlm_attention_mask is not None:
        vlm_hidden_states = vlm_hidden_states * vlm_attention_mask.unsqueeze(-1).to(vlm_hidden_states.dtype)
    return vlm_hidden_states, vlm_attention_mask


def prepare_video_conditioned_action_vlm_states(
    self,
    block_idx: int,
    video_hidden_states: torch.Tensor,
    base_vlm_hidden_states: Optional[torch.Tensor],
    base_vlm_attention_mask: Optional[torch.Tensor],
):
    if base_vlm_hidden_states is None:
        return None, None
    if getattr(self, "action_vlm_adapter_mode", "global") != "video_conditioned":
        return base_vlm_hidden_states, base_vlm_attention_mask
    if not hasattr(self, "action_vlm_block_adapters"):
        return None, None

    block_start = int(getattr(self, "action_vlm_block_start", 0))
    adapter_idx = block_idx - block_start
    if adapter_idx < 0 or adapter_idx >= len(self.action_vlm_block_adapters):
        return None, None

    if video_hidden_states.shape[0] != base_vlm_hidden_states.shape[0]:
        assert base_vlm_hidden_states.shape[0] % video_hidden_states.shape[0] == 0, (
            "video hidden states batch size is not aligned with VLM/action batch size"
        )
        repeat = base_vlm_hidden_states.shape[0] // video_hidden_states.shape[0]
        video_hidden_states = video_hidden_states.repeat_interleave(repeat, dim=0)

    refined_vlm = self.action_vlm_block_adapters[adapter_idx](
        video_hidden_states,
        base_vlm_hidden_states,
        base_vlm_attention_mask,
    )
    refined_mask = torch.ones(
        refined_vlm.shape[:2],
        device=refined_vlm.device,
        dtype=torch.bool,
    )
    return refined_vlm, refined_mask


def prepare_action_history_states(self, context_dict, action_hidden_states):
    if context_dict is None or not hasattr(self, "action_his_traj_encoder"):
        return None

    hist_traj = context_dict.get("hist_traj", context_dict.get("history_trajectory"))
    if hist_traj is None:
        return None

    B, T, _ = action_hidden_states.shape
    hist_traj = hist_traj.to(device=action_hidden_states.device, dtype=action_hidden_states.dtype)
    if hist_traj.ndim == 2:
        hist_traj = hist_traj.unsqueeze(0)
    if hist_traj.shape[0] != B:
        assert B % hist_traj.shape[0] == 0, "history trajectory batch size is not aligned with action batch size"
        hist_traj = hist_traj.repeat_interleave(B // hist_traj.shape[0], dim=0)

    hist_flat = hist_traj.reshape(hist_traj.shape[0], -1)
    if hist_flat.shape[-1] != 12:
        raise ValueError(f"history trajectory must flatten to 12 dims, got {hist_flat.shape[-1]}")

    return self.action_his_traj_encoder(hist_flat.unsqueeze(1)).repeat(1, T, 1)


class LTXVideoAttentionProcessor2_0:
    def __new__(cls, *args, **kwargs):
        deprecation_message = "`LTXVideoAttentionProcessor2_0` is deprecated and this will be removed in a future version. Please use `LTXVideoAttnProcessor`"
        deprecate("LTXVideoAttentionProcessor2_0", "1.0.0", deprecation_message)

        return LTXVideoAttnProcessor(*args, **kwargs)


class LTXVideoAttnProcessor:
    r"""
    Processor for implementing attention (SDPA is used by default if you're using PyTorch 2.0). This is used in the LTX
    model. It applies a normalization layer and rotary embedding on the query and key vector.
    """

    _attention_backend = None
    _parallel_config = None

    def __init__(self):
        if is_torch_version("<", "2.0"):
            raise ValueError(
                "LTX attention processors require a minimum PyTorch version of 2.0. Please upgrade your PyTorch installation."
            )

    def __call__(
        self,
        attn: "LTXAttention",
        hidden_states: torch.Tensor,
        encoder_hidden_states: Optional[torch.Tensor] = None,
        attention_mask: Optional[torch.Tensor] = None,
        image_rotary_emb: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        batch_size, sequence_length, _ = (
            hidden_states.shape if encoder_hidden_states is None else encoder_hidden_states.shape
        )

        if attention_mask is not None:
            attention_mask = attn.prepare_attention_mask(attention_mask, sequence_length, batch_size)
            attention_mask = attention_mask.view(batch_size, attn.heads, -1, attention_mask.shape[-1])

        if encoder_hidden_states is None:
            encoder_hidden_states = hidden_states

        query = attn.to_q(hidden_states)
        key = attn.to_k(encoder_hidden_states)
        value = attn.to_v(encoder_hidden_states)

        query = attn.norm_q(query)
        key = attn.norm_k(key)

        if image_rotary_emb is not None:
            query = apply_rotary_emb(query, image_rotary_emb)
            key = apply_rotary_emb(key, image_rotary_emb)

        query = query.unflatten(2, (attn.heads, -1))
        key = key.unflatten(2, (attn.heads, -1))
        value = value.unflatten(2, (attn.heads, -1))

        hidden_states = dispatch_attention_fn(
            query,
            key,
            value,
            attn_mask=attention_mask,
            dropout_p=0.0,
            is_causal=False,
            backend=self._attention_backend,
            #parallel_config=self._parallel_config,
        )
        hidden_states = hidden_states.flatten(2, 3)
        hidden_states = hidden_states.to(query.dtype)

        hidden_states = attn.to_out[0](hidden_states)
        hidden_states = attn.to_out[1](hidden_states)
        return hidden_states

class ActionTrajectoryScorer(nn.Module):
    def __init__(self,
                 action_dim=3,
                 hidden=512,         # scorer 内部维度 D
                 heads=8,
                 dim_head=64,
                 ctx_dim=128        # 你的视频上下文 token 维度（inner_dim）
                 ):
        super().__init__()
        D = hidden

        self.act_in = nn.Linear(action_dim, D)
        self.rope   = ActionRotaryPosEmbed(dim=D, base_seq_length=128)

        self.ctx_proj = nn.Linear(ctx_dim, D)

        self.q_norm = nn.LayerNorm(D)
        self.attn   = Attention(
            query_dim=D, heads=heads, kv_heads=heads, dim_head=dim_head,
            cross_attention_dim=D, bias=True, out_bias=True, qk_norm="rms_norm_across_heads",processor=LTXVideoAttentionProcessor2_0()
        )

        self.ffn  = SwiGLUFFN(D, bias=True)
        self.out  = nn.Sequential(nn.LayerNorm(D), nn.Linear(D, 1))

    def forward(self,
                actions_bk: torch.Tensor,
                ctx_tokens: torch.Tensor,
                ctx_mask: torch.Tensor = None 
                ):
        B, K, L, Ca = actions_bk.shape
        D = self.act_in.out_features

        x = self.act_in(actions_bk.view(B*K, L, Ca))   # (B*K, L, D)
        cos, sin = self.rope(x, L)                     # (1, L, D)
        x = apply_rotary_emb(x, (cos, sin))            # (B*K, L, D)
        x = self.q_norm(x)

        kv = self.ctx_proj(ctx_tokens.detach())        # (B, S_ctx, D)
        #kv = kv.repeat_interleave(K, dim=0)            # (B*K, S_ctx, D)


        
        x = self.attn(x, encoder_hidden_states=kv, attention_mask=None)
        x = self.ffn(x)                                  # (B*K, L, D)

        x = x.mean(dim=1)                                # (B*K, D)
        logits = self.out(x).view(B, K)                  # (B, K)

        return logits


def apply_rotary_emb(x, freqs):
    cos, sin = freqs
    x_real, x_imag = x.unflatten(2, (-1, 2)).unbind(-1)  # [B, S, C // 2]
    x_rotated = torch.stack([-x_imag, x_real], dim=-1).flatten(2)
    out = (x.float() * cos + x_rotated.float() * sin).to(x.dtype)
    return out

class ActionRotaryPosEmbed(nn.Module):
    def __init__(
        self,
        dim: int,
        base_seq_length: int = 57,
        theta: float = 10000.0,
    ) -> None:
        super().__init__()

        self.dim = dim
        self.base_seq_length = base_seq_length
        self.theta = theta

    def forward(
        self,
        hidden_states: torch.Tensor,
        seq_length: int,
    ) -> Tuple[torch.Tensor, torch.Tensor]:

        # Always compute rope in fp32
        grid = torch.arange(seq_length, dtype=torch.float32, device=hidden_states.device).unsqueeze(0)

        grid = grid / self.base_seq_length

        grid = grid.unsqueeze(-1)

        start = 1.0
        end = self.theta
        freqs = self.theta ** torch.linspace(
            math.log(start, self.theta),
            math.log(end, self.theta),
            self.dim // 2,
            device=hidden_states.device,
            dtype=torch.float32,
        )
        freqs = freqs * math.pi / 2.0
        freqs = freqs * (grid * 2 - 1)

        cos_freqs = freqs.cos().repeat_interleave(2, dim=-1)
        sin_freqs = freqs.sin().repeat_interleave(2, dim=-1)

        if self.dim % 2 != 0:
            cos_padding = torch.ones_like(cos_freqs[:, :, : self.dim % 2])
            sin_padding = torch.zeros_like(sin_freqs[:, :, : self.dim % 2])
            cos_freqs = torch.cat([cos_padding, cos_freqs], dim=-1)
            sin_freqs = torch.cat([sin_padding, sin_freqs], dim=-1)

        return cos_freqs, sin_freqs




@maybe_allow_in_graph
class ActionTransformerBlock(nn.Module):
    r"""
    Modified from Transformer block used in [LTX](https://huggingface.co/Lightricks/LTX-Video).

    Args:
        dim (`int`):
            The number of channels in the input and output.
        num_attention_heads (`int`):
            The number of heads to use for multi-head attention.
        attention_head_dim (`int`):
            The number of channels in each head.
        qk_norm (`str`, defaults to `"rms_norm"`):
            The normalization layer to use.
        activation_fn (`str`, defaults to `"gelu-approximate"`):
            Activation function to use in feed-forward.
        eps (`float`, defaults to `1e-6`):
            Epsilon value for normalization layers.
    """

    def __init__(
        self,
        attention_class,
        attention_args,
        dim: int = 512,
        num_attention_heads: int = 16,
        attention_head_dim: int = 32,
        cross_attention_dim: int = 2048,
        qk_norm: str = "rms_norm_across_heads",
        activation_fn: str = "gelu-approximate",
        attention_bias: bool = True,
        attention_out_bias: bool = True,
        eps: float = 1e-6,
        elementwise_affine: bool = False,
        attn3_cross_attention_dim = 2048,
        num_latent_downsample_block = 0,
        vlm_enable: bool = False,
        vlm_fusion_mode: str = "cross_attention",
        vlm_gate_init: float = 0.0,
    ):
        super().__init__()
        if isinstance(vlm_enable, str):
            vlm_enable = vlm_enable.strip().lower() in ("1", "true", "yes", "y")
        self.vlm_enable = bool(vlm_enable)
        vlm_fusion_mode = str(vlm_fusion_mode or "cross_attention").strip().lower()
        if vlm_fusion_mode != "cross_attention":
            raise ValueError("action VLM fusion only supports the default 'cross_attention' path.")
        self.vlm_fusion_mode = "cross_attention"

        self.norm1 = RMSNorm(dim, eps=eps, elementwise_affine=elementwise_affine)
        self.attn1 = attention_class(
            **(attention_args[0]),
        )

        self.norm2 = RMSNorm(dim, eps=eps, elementwise_affine=elementwise_affine)
        self.attn2 = attention_class(
            **(attention_args[1]),
        )
        if self.vlm_enable:
            self.norm3 = RMSNorm(dim, eps=eps, elementwise_affine=elementwise_affine)
            self.attn3 = attention_class(
                **(attention_args[2]),
            )
            # Kept for state-dict and initialization compatibility with the
            # previous cross_attention configuration. These modules are not
            # used by the remaining default cross-attention path.
            self.vlm_to_action = nn.Linear(cross_attention_dim, dim)
            self.vlm_film = nn.Sequential(
                nn.LayerNorm(cross_attention_dim),
                nn.Linear(cross_attention_dim, dim * 2),
            )
            self.vlm_concat_proj = nn.Linear(dim * 2, dim)

        #self.ff = FeedForward(dim, activation_fn=activation_fn)
        self.ff = SwiGLUFFN(dim, bias=True)

        self.scale_shift_table = nn.Parameter(torch.randn(6, dim) / dim**0.5)

        self.num_latent_downsample_block = num_latent_downsample_block
        if self.num_latent_downsample_block > 0:
            self.latent_downsample_block = nn.ModuleList()
            for _i in range(self.num_latent_downsample_block):
                self.latent_downsample_block.append(
                    downsampling_block()
                )

    def forward(
        self,
        hidden_states: torch.Tensor,
        encoder_hidden_states: torch.Tensor,
        temb: torch.Tensor,
        rotary_emb: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,
        encoder_attention_mask: Optional[torch.Tensor] = None,
        vlm_hidden_states: Optional[torch.Tensor] = None,
        vlm_attention_mask: Optional[torch.Tensor] = None,
        block_idx: Optional[int] = None,
    ) -> torch.Tensor:
        B, Tq, D = hidden_states.shape

        batch_size = hidden_states.size(0)
        norm_hidden_states = self.norm1(hidden_states)

        num_ada_params = self.scale_shift_table.shape[0]
        if temb.shape[-1] == D * num_ada_params:
            ada_values = self.scale_shift_table[None, None] + temb.view(B, Tq, num_ada_params, D)
        elif temb.shape[-1] == D:
            ada_core = temb.unsqueeze(2).expand(B, Tq, num_ada_params, D)
            ada_values = self.scale_shift_table[None, None] + ada_core
        else:
            raise ValueError(f"temb last dim {temb.shape[-1]} not in {{D, 6*D}} with D={D}")

        shift_msa, scale_msa, gate_msa, shift_mlp, scale_mlp, gate_mlp = ada_values.unbind(dim=2)
        norm_hidden_states = norm_hidden_states * (1 + scale_msa) + shift_msa

        use_vlm = self.vlm_enable and vlm_hidden_states is not None
        if use_vlm:
            if vlm_attention_mask is not None:
                vlm_attention_mask = vlm_attention_mask.to(device=vlm_hidden_states.device, dtype=torch.bool)
                vlm_attention_bias = (~vlm_attention_mask).to(vlm_hidden_states.dtype).unsqueeze(1) * -10000.0
            else:
                vlm_attention_bias = None
        else:
            vlm_attention_bias = None
        if encoder_attention_mask is not None and encoder_attention_mask.ndim == 2:
            encoder_attention_mask = (1 - encoder_attention_mask.to(hidden_states.dtype)).unsqueeze(1) * -10000.0

        
        attn_hidden_states = self.attn1(
            hidden_states=norm_hidden_states,
            encoder_hidden_states=None,
            image_rotary_emb=rotary_emb,
        )
        hidden_states = hidden_states + attn_hidden_states * gate_msa

        attn_hidden_states = self.attn2(
            hidden_states,
            encoder_hidden_states=encoder_hidden_states,
            image_rotary_emb=None,
            attention_mask=encoder_attention_mask,
        )
        hidden_states = hidden_states + attn_hidden_states

        if use_vlm:
            norm_vlm_query_states = self.norm3(hidden_states)
            attn_hidden_states = self.attn3(
                norm_vlm_query_states,
                encoder_hidden_states=vlm_hidden_states,
                image_rotary_emb=None,
                attention_mask=vlm_attention_bias,
            )
            hidden_states = hidden_states + attn_hidden_states

        norm_hidden_states = self.norm2(hidden_states) * (1 + scale_mlp) + shift_mlp
        

        ff_output = self.ff(norm_hidden_states)
        hidden_states = hidden_states + ff_output * gate_mlp
        

        return hidden_states



def add_action_expert(
    self,
    num_layers: int = 28,
    inner_dim: int = 2048,
    activation_fn: str = "gelu",
    norm_eps: float = 1e-6,
    action_in_channels: int = 3,
    action_out_channels: int = 3,
    action_num_attention_heads: int = 16,
    action_attention_head_dim: int = 32,
    action_rope_dim: int = None,
    action_final_embeddings: bool = True,
    learnable_action_state: bool = False,
    norm_elementwise_affine: bool = False,
    attention_bias: bool = True,
    attention_out_bias: bool = True,
    qk_norm: str = "rms_norm_across_heads",
    attention_class = None,
    attention_processor = None,
    action_vlm_enable: bool = False,
    action_vlm_hidden_dim: int = 1536,
    action_vlm_fusion_mode: str = "cross_attention",
    action_vlm_compress_tokens: bool = False,
    action_vlm_num_queries: int = 32,
    action_vlm_context_dim: Optional[int] = None,
    action_vlm_adapter_mode: str = "global",
    action_vlm_block_start: int = 0,
    action_vlm_video_pool_tokens: int = 64,
    action_history_input: bool = True,
    joint_vlm_enable: bool = False,
    joint_vlm_hidden_dim: Optional[int] = None,
    joint_vlm_context_dim: Optional[int] = None,
    joint_video_attend_vlm: bool = False,
    **kwargs,
):

    if action_out_channels is None:
        action_out_channels = action_in_channels

    self.action_inner_dim = action_num_attention_heads * action_attention_head_dim

    self.learnable_action_state = learnable_action_state
    if self.learnable_action_state:
        self.action_state = nn.Parameter(torch.randn(1, 1, action_in_channels))

    self.action_proj_in = nn.Linear(action_in_channels, self.action_inner_dim)
    self.action_scale_shift_table = nn.Parameter(torch.randn(2, self.action_inner_dim) / self.action_inner_dim**0.5)
    self.action_time_embed = AdaLayerNormSingle(self.action_inner_dim, use_additional_conditions=False)

    self.action_ego_status_encoder = Mlp(
        in_features=20,
        hidden_features=self.action_inner_dim*2,
        out_features=self.action_inner_dim,
        norm_layer=nn.LayerNorm
    )
    action_history_input = _as_bool(action_history_input)
    if action_history_input:
        self.action_his_traj_encoder = Mlp(
            in_features=12,
            hidden_features=self.action_inner_dim * 2,
            out_features=self.action_inner_dim,
            norm_layer=nn.LayerNorm,
        )
    self.action_state_film = nn.Sequential(
        nn.Linear(self.action_inner_dim, self.action_inner_dim * 2),
        nn.SiLU(),
        nn.Linear(self.action_inner_dim * 2, self.action_inner_dim * 6),
    )
    if action_rope_dim is None:
        action_rope_dim = self.action_inner_dim
    # set to a fixed value currently, should adjust according to the action length
    self.action_rope = ActionRotaryPosEmbed(
        dim=action_rope_dim,
        base_seq_length=8,
        theta=10000.0,
    )

    attention_args = []
    attention_args.append(dict(
        query_dim=self.action_inner_dim,
        heads=action_num_attention_heads,
        kv_heads=action_num_attention_heads,
        dim_head=action_attention_head_dim,
        bias=attention_bias,
        cross_attention_dim=None,
        out_bias=attention_out_bias,
        qk_norm=qk_norm,
        processor=attention_processor,
    ))
    attention_args.append(dict(
        query_dim=self.action_inner_dim,
        heads=action_num_attention_heads,
        kv_heads=action_num_attention_heads,
        dim_head=action_attention_head_dim,
        bias=attention_bias,
        cross_attention_dim=inner_dim,
        out_bias=attention_out_bias,
        qk_norm=qk_norm,
        processor=attention_processor,
    ))
    action_vlm_enable = _as_bool(action_vlm_enable)
    action_vlm_compress_tokens = _as_bool(action_vlm_compress_tokens)
    action_vlm_num_queries = int(action_vlm_num_queries)
    if action_vlm_num_queries <= 0:
        raise ValueError("action_vlm_num_queries must be positive.")
    action_vlm_video_pool_tokens = int(action_vlm_video_pool_tokens)
    if action_vlm_video_pool_tokens <= 0:
        raise ValueError("action_vlm_video_pool_tokens must be positive.")
    adapter_mode_aliases = {
        "default": "global",
        "legacy": "global",
        "shared": "global",
        "global_resampler": "global",
        "video-conditioned": "video_conditioned",
        "video_condition": "video_conditioned",
        "video_cond": "video_conditioned",
        "video_conditioned_bottleneck": "video_conditioned",
    }
    action_vlm_adapter_mode = adapter_mode_aliases.get(
        str(action_vlm_adapter_mode).strip().lower(),
        str(action_vlm_adapter_mode).strip().lower(),
    )
    if action_vlm_adapter_mode not in {"global", "video_conditioned"}:
        raise ValueError("action_vlm_adapter_mode must be 'global' or 'video_conditioned'.")
    if action_vlm_context_dim in (None, ""):
        action_vlm_context_dim = self.action_inner_dim
    action_vlm_context_dim = int(action_vlm_context_dim)
    if action_vlm_context_dim <= 0:
        raise ValueError("action_vlm_context_dim must be positive.")
    action_vlm_fusion_mode = str(action_vlm_fusion_mode or "cross_attention").strip().lower()
    if action_vlm_fusion_mode != "cross_attention":
        raise ValueError("action_vlm_fusion_mode only supports the default 'cross_attention' path.")
    self.action_vlm_adapter_mode = action_vlm_adapter_mode
    self.action_vlm_block_start = int(action_vlm_block_start)
    self.action_vlm_video_pool_tokens = action_vlm_video_pool_tokens
    joint_vlm_enable = _as_bool(joint_vlm_enable)
    self.joint_vlm_enable = joint_vlm_enable
    joint_video_attend_vlm = _as_bool(joint_video_attend_vlm)
    self.joint_video_attend_vlm = joint_video_attend_vlm
    if joint_vlm_hidden_dim in (None, ""):
        joint_vlm_hidden_dim = action_vlm_hidden_dim
    joint_vlm_hidden_dim = int(joint_vlm_hidden_dim)
    if joint_vlm_context_dim in (None, ""):
        joint_vlm_context_dim = action_vlm_context_dim
    joint_vlm_context_dim = int(joint_vlm_context_dim)
    if joint_vlm_context_dim <= 0:
        raise ValueError("joint_vlm_context_dim must be positive.")
    build_action_vlm_path = action_vlm_enable and not joint_vlm_enable
    if build_action_vlm_path:
        attention_args.append(dict(
            query_dim=self.action_inner_dim,
            heads=action_num_attention_heads,
            kv_heads=action_num_attention_heads,
            dim_head=action_attention_head_dim,
            bias=attention_bias,
            cross_attention_dim=action_vlm_context_dim,
            out_bias=attention_out_bias,
            qk_norm=qk_norm,
            processor=attention_processor,
        ))
        if action_vlm_adapter_mode == "video_conditioned":
            self.action_vlm_projector = VLMFeatureProjector(
                input_dim=action_vlm_hidden_dim,
                output_dim=action_vlm_context_dim,
            )
            if self.action_vlm_block_start < 0:
                active_block_start = num_layers
            else:
                active_block_start = min(max(self.action_vlm_block_start, 0), num_layers)
            self.action_vlm_block_start = active_block_start
            self.action_vlm_block_adapters = nn.ModuleList(
                [
                    VideoConditionedVLMAdapter(
                        video_dim=inner_dim,
                        dim=action_vlm_context_dim,
                        video_pool_tokens=action_vlm_video_pool_tokens,
                        vlm_queries=action_vlm_num_queries,
                        heads=action_num_attention_heads,
                    )
                    for _ in range(num_layers - active_block_start)
                ]
            )
            if action_history_input:
                self.action_history_input_projector = nn.Linear(self.action_inner_dim * 2, self.action_inner_dim)
                nn.init.zeros_(self.action_history_input_projector.weight)
                nn.init.zeros_(self.action_history_input_projector.bias)
                with torch.no_grad():
                    self.action_history_input_projector.weight[:, self.action_inner_dim:] = torch.eye(
                        self.action_inner_dim
                    )
        elif action_vlm_compress_tokens:
            self.action_vlm_resampler = VLMQueryResampler(
                input_dim=action_vlm_hidden_dim,
                output_dim=action_vlm_context_dim,
                num_queries=action_vlm_num_queries,
                num_heads=action_num_attention_heads,
                depth=2,
            )
        else:
            self.action_vlm_proj = nn.Linear(action_vlm_hidden_dim, action_vlm_context_dim)
        if action_vlm_adapter_mode == "global":
            if action_vlm_context_dim != self.action_inner_dim:
                self.action_vlm_pooled_proj = nn.Linear(action_vlm_context_dim, self.action_inner_dim)
            self.action_vlm_input_fusion_projector = nn.Linear(self.action_inner_dim * 3, self.action_inner_dim)
            nn.init.zeros_(self.action_vlm_input_fusion_projector.weight)
            nn.init.zeros_(self.action_vlm_input_fusion_projector.bias)
            with torch.no_grad():
                self.action_vlm_input_fusion_projector.weight[:, self.action_inner_dim * 2:] = torch.eye(
                    self.action_inner_dim
                )

    if joint_vlm_enable:
        self.joint_vlm_context_dim = joint_vlm_context_dim
        if action_vlm_compress_tokens:
            self.joint_vlm_resampler = VLMQueryResampler(
                input_dim=joint_vlm_hidden_dim,
                output_dim=joint_vlm_context_dim,
                num_queries=action_vlm_num_queries,
                num_heads=action_num_attention_heads,
                depth=2,
            )
        else:
            self.joint_vlm_projector = VLMFeatureProjector(
                input_dim=joint_vlm_hidden_dim,
                output_dim=joint_vlm_context_dim,
            )
        self.joint_action_rope = ActionRotaryPosEmbed(
            dim=inner_dim,
            base_seq_length=8,
            theta=10000.0,
        )
        self.joint_vlm_blocks = nn.ModuleList(
            [
                MaskedJointVLMBlock(
                    video_dim=inner_dim,
                    vlm_dim=joint_vlm_context_dim,
                    action_dim=self.action_inner_dim,
                    joint_dim=inner_dim,
                    eps=norm_eps,
                    attention_bias=attention_bias,
                    attention_out_bias=attention_out_bias,
                    video_attend_vlm=joint_video_attend_vlm,
                )
                for _ in range(num_layers)
            ]
        )
        if action_history_input and not hasattr(self, "action_history_input_projector"):
            self.action_history_input_projector = nn.Linear(self.action_inner_dim * 2, self.action_inner_dim)
            nn.init.zeros_(self.action_history_input_projector.weight)
            nn.init.zeros_(self.action_history_input_projector.bias)
            with torch.no_grad():
                self.action_history_input_projector.weight[:, self.action_inner_dim:] = torch.eye(
                    self.action_inner_dim
                )

    self.action_blocks = nn.ModuleList(
        [
            ActionTransformerBlock(
                attention_class = attention_class,
                attention_args = attention_args,
                dim=self.action_inner_dim,
                num_attention_heads=action_num_attention_heads,
                attention_head_dim=action_attention_head_dim,
                cross_attention_dim=action_vlm_context_dim,
                qk_norm=qk_norm,
                activation_fn=activation_fn,
                attention_bias=attention_bias,
                attention_out_bias=attention_out_bias,
                eps=norm_eps,
                elementwise_affine=norm_elementwise_affine,
                vlm_enable=build_action_vlm_path,
                vlm_fusion_mode=action_vlm_fusion_mode,
            )
            for _ in range(num_layers)
        ]
    )

    self.action_proj_out = nn.Linear(self.action_inner_dim, action_out_channels) 
    self.action_final_embeddings = action_final_embeddings
    if not self.action_final_embeddings:
        self.action_proj_extra = nn.Linear(self.action_inner_dim, self.action_inner_dim)

    self.action_norm_out = nn.LayerNorm(self.action_inner_dim, eps=1e-6, elementwise_affine=False)


def preprocessing_action_states(
    self,
    action_states: torch.Tensor = None,
    action_timestep: torch.LongTensor = None,
    context_dict: Optional[Dict[str, torch.Tensor]] = None,
):

    assert self.action_expert == True
    assert action_states is not None and action_timestep is not None
    assert context_dict is not None, "context_dict is required for ego/hist injection"

    batch_size = action_states.shape[0]

    device = action_states.device
    dtype  = action_states.dtype
    B, T, _ = action_states.shape

    action_seq_length = action_states.shape[1]

    if getattr(self, "learnable_action_state") and self.learnable_action_state:
        action_states = self.action_state.repeat(batch_size, action_seq_length, 1).to(dtype=action_states.dtype, device=action_states.device)

    action_rotary_emb = self.action_rope(action_states, action_seq_length)
    action_hidden_states = self.action_proj_in(action_states)

    action_temb, action_embedded_timestep = self.action_time_embed(
        action_timestep.flatten(),
        batch_size=batch_size,
        hidden_dtype=action_hidden_states.dtype,
    )
    action_temb = action_temb.view(batch_size, -1, action_temb.size(-1))
    action_embedded_timestep = action_embedded_timestep.view(batch_size, -1, action_embedded_timestep.size(-1))
    
    cmd_onehot = context_dict["cmd_onehot"].to(device=device, dtype=dtype)     # (B, Ccmd)
    vel        = context_dict["vel"].to(device=device, dtype=dtype)            # (B, 2)
    acc        = context_dict["acc"].to(device=device, dtype=dtype)            # (B, 2)
    hist_traj  = context_dict.get("hist_traj", context_dict.get("history_trajectory"))
    assert hist_traj is not None, "hist_traj is required for action state conditioning"
    hist_traj = hist_traj.to(device=device, dtype=dtype)
    if hist_traj.ndim == 2:
        hist_traj = hist_traj.unsqueeze(0)
    if hist_traj.shape[0] != B:
        assert B % hist_traj.shape[0] == 0, "history trajectory batch size is not aligned with action batch size"
        hist_traj = hist_traj.repeat_interleave(B // hist_traj.shape[0], dim=0)
    hist_flat = hist_traj.reshape(hist_traj.shape[0], -1)
    if hist_flat.shape[-1] != 12:
        raise ValueError(f"history trajectory must flatten to 12 dims, got {hist_flat.shape[-1]}")

    ego_state = torch.cat([vel, acc, cmd_onehot, hist_flat], dim=-1)       # (B, 20)
    ego_emb = self.action_ego_status_encoder(ego_state)                # (B, D)
    ego_emb = ego_emb.unsqueeze(1).repeat(1, T, 1)              # (B, T, D)
    state_film_6D = self.action_state_film(ego_emb).view(B, T, 6, -1)               # (B,T,6,D_action)
    temb_time_6D  = action_temb.view(B, T, 6, -1)                             # (B,T,6,D_action)  ✅
    temb_fused    = (state_film_6D + temb_time_6D).reshape(B, T, -1)          # (B,T,6*D_action)


    return temb_fused, action_embedded_timestep, action_rotary_emb, action_hidden_states
