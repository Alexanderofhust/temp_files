from __future__ import annotations

from typing import Any, Dict, List, Tuple, Union

import torch
import transformers
from torch import nn

from .utils.utils import format_number


PIXELS_PER_TOKEN = 32**2
DEFAULT_SYSTEM_PROMPT = "You are a helpful assistant."


def _resolve_torch_dtype(dtype: Union[str, torch.dtype]) -> Union[str, torch.dtype]:
    if isinstance(dtype, torch.dtype):
        return dtype

    normalized = str(dtype).lower()
    if normalized == "auto":
        return "auto"

    dtype_map = {
        "float16": torch.float16,
        "fp16": torch.float16,
        "half": torch.float16,
        "bfloat16": torch.bfloat16,
        "bf16": torch.bfloat16,
        "float32": torch.float32,
        "fp32": torch.float32,
    }
    if normalized not in dtype_map:
        raise ValueError(f"Unsupported dtype: {dtype!r}")
    return dtype_map[normalized]


def _as_bool(value: Union[bool, str]) -> bool:
    if isinstance(value, str):
        return value.strip().lower() in ("1", "true", "yes", "y")
    return bool(value)


class CosmosReasonBackbone(nn.Module):
    """Cosmos-Reason2/Qwen3-VL wrapper used for online hidden-state conditioning."""

    def __init__(
        self,
        model_path: str,
        device: str = "cuda",
        model_dtype: Union[str, torch.dtype] = "float16",
        attn_implementation: str = "sdpa",
        min_vision_tokens: int = 256,
        max_vision_tokens: int = 8192,
        system_prompt: str = DEFAULT_SYSTEM_PROMPT,
    ):
        super().__init__()
        self.device = device
        self.system_prompt = system_prompt

        model_cls = getattr(transformers, "Qwen3VLForConditionalGeneration", None)
        processor_cls = getattr(transformers, "Qwen3VLProcessor", None)
        if model_cls is None or processor_cls is None:
            raise ImportError(
                "Cosmos-Reason2 requires a transformers build with Qwen3-VL support. "
                "The sample script pins transformers==4.57.3."
            )

        dtype = _resolve_torch_dtype(model_dtype)
        model_kwargs = {
            "dtype": dtype,
            "device_map": {"": device},
            "attn_implementation": attn_implementation,
        }
        try:
            self.model = model_cls.from_pretrained(model_path, **model_kwargs).eval()
        except TypeError:
            model_kwargs["torch_dtype"] = model_kwargs.pop("dtype")
            self.model = model_cls.from_pretrained(model_path, **model_kwargs).eval()

        self.processor = processor_cls.from_pretrained(model_path)
        self._configure_vision_token_limits(min_vision_tokens, max_vision_tokens)

    def _configure_vision_token_limits(self, min_vision_tokens: int, max_vision_tokens: int) -> None:
        size = {
            "shortest_edge": min_vision_tokens * PIXELS_PER_TOKEN,
            "longest_edge": max_vision_tokens * PIXELS_PER_TOKEN,
        }
        if hasattr(self.processor, "image_processor"):
            self.processor.image_processor.size = size
        if hasattr(self.processor, "video_processor"):
            self.processor.video_processor.size = size

    @torch.inference_mode()
    def forward(self, image_path: str, prompt: str) -> Tuple[Any, Dict[str, torch.Tensor]]:
        conversation = self._build_user_conversation(image_path=image_path, prompt=prompt)
        inputs = self.processor.apply_chat_template(
            conversation,
            tokenize=True,
            add_generation_prompt=True,
            return_dict=True,
            return_tensors="pt",
        )
        self._validate_multimodal_inputs(inputs)
        inputs = inputs.to(self.model.device)
        outputs = self.model(
            **inputs,
            output_hidden_states=True,
            return_dict=True,
            use_cache=False,
        )
        return outputs, inputs

    @torch.inference_mode()
    def generate(
        self,
        image_path: str,
        prompt: str,
        max_new_tokens: int = 80,
        do_sample: Union[bool, str] = False,
        repetition_penalty: float = 1.03,
        no_repeat_ngram_size: int = 0,
    ) -> str:
        conversation = self._build_user_conversation(image_path=image_path, prompt=prompt)
        inputs = self.processor.apply_chat_template(
            conversation,
            tokenize=True,
            add_generation_prompt=True,
            return_dict=True,
            return_tensors="pt",
        )
        self._validate_multimodal_inputs(inputs)
        inputs = inputs.to(self.model.device)

        generation_kwargs = {
            "max_new_tokens": int(max_new_tokens),
            "do_sample": _as_bool(do_sample),
        }
        if repetition_penalty and float(repetition_penalty) != 1.0:
            generation_kwargs["repetition_penalty"] = float(repetition_penalty)
        if no_repeat_ngram_size and int(no_repeat_ngram_size) > 0:
            generation_kwargs["no_repeat_ngram_size"] = int(no_repeat_ngram_size)

        generated_ids = self.model.generate(
            **inputs,
            **generation_kwargs,
        )
        generated_ids_trimmed = [
            out_ids[len(in_ids) :]
            for in_ids, out_ids in zip(inputs.input_ids, generated_ids, strict=False)
        ]
        output_text = self.processor.batch_decode(
            generated_ids_trimmed,
            skip_special_tokens=True,
            clean_up_tokenization_spaces=False,
        )
        return output_text[0].strip() if output_text else ""

    @torch.inference_mode()
    def forward_with_assistant(
        self,
        image_path: str,
        user_prompt: str,
        assistant_output_text: str,
    ) -> Tuple[Any, Dict[str, torch.Tensor]]:
        conversation = self._build_user_conversation(image_path=image_path, prompt=user_prompt)
        conversation.append(
            {
                "role": "assistant",
                "content": [{"type": "text", "text": assistant_output_text}],
            }
        )
        inputs = self.processor.apply_chat_template(
            conversation,
            tokenize=True,
            add_generation_prompt=False,
            return_dict=True,
            return_tensors="pt",
        )
        self._validate_multimodal_inputs(inputs)
        inputs = inputs.to(self.model.device)
        outputs = self.model(
            **inputs,
            output_hidden_states=True,
            return_dict=True,
            use_cache=False,
        )
        return outputs, inputs

    def _build_user_conversation(self, image_path: str, prompt: str) -> List[Dict[str, Any]]:
        return [
            {
                "role": "system",
                "content": [{"type": "text", "text": self.system_prompt}],
            },
            {
                "role": "user",
                "content": [
                    {"type": "image", "image": image_path},
                    {"type": "text", "text": prompt},
                ],
            },
        ]

    @staticmethod
    def _validate_multimodal_inputs(inputs: Dict[str, Any]) -> None:
        input_keys = set(inputs.keys())
        if "input_ids" not in input_keys:
            raise ValueError(f"Qwen3VLProcessor did not return input_ids. Returned keys: {sorted(input_keys)}")

        vision_keys = {
            "pixel_values",
            "pixel_values_videos",
            "image_grid_thw",
            "video_grid_thw",
        }
        if input_keys.isdisjoint(vision_keys):
            raise ValueError(
                "Qwen3VLProcessor did not return any vision tensors. "
                f"Returned keys: {sorted(input_keys)}. "
                "Check that the user content contains an image/video item before text."
            )


def _resolve_prompt_values(
    history_trajectory: torch.Tensor,
    high_command_one_hot: torch.Tensor,
    current_velocity: torch.Tensor,
    current_acceleration: torch.Tensor,
) -> Tuple[str, str, str, str, str, str]:
    navigation_commands = ["turn left", "go straight", "turn right"]
    command_str = next(
        (navigation_commands[i] for i, value in enumerate(high_command_one_hot) if value == 1),
        "unknown",
    )
    history_str = "\n".join(
        [
            f"  - t-{3 - i}: ("
            f"{format_number(history_trajectory[i, 0].item())}, "
            f"{format_number(history_trajectory[i, 1].item())}, "
            f"{format_number(history_trajectory[i, 2].item())})"
            for i in range(4)
        ]
    )
    vx = format_number(current_velocity[0].item())
    vy = format_number(current_velocity[1].item())
    ax = format_number(current_acceleration[0].item())
    ay = format_number(current_acceleration[1].item())
    return history_str, command_str.upper(), vx, vy, ax, ay


def _normalize_generated_line(text: str) -> str:
    return " ".join(str(text).strip().split())


def _looks_like_bad_generation(text: str) -> bool:
    stripped = text.strip()
    if not stripped:
        return True
    lower = stripped.lower()
    if stripped.startswith(("[", "{")) or stripped.endswith(("]", "}")):
        return True
    if lower.count("no_") >= 8:
        return True
    if len(stripped.split()) > 120 or len(stripped) > 900:
        return True
    bad_phrases = (
        "drive launch cycle",
        "range limiter",
        "carjacking",
        "paramecia",
        "defib",
        "no_unknown_no_",
    )
    if any(phrase in lower for phrase in bad_phrases):
        return True
    return False


def sanitize_cosmos_official_av_output(text: str, high_command_one_hot: torch.Tensor) -> str:
    navigation_commands = ["TURN LEFT", "GO STRAIGHT", "TURN RIGHT"]
    command_str = next(
        (navigation_commands[i] for i, value in enumerate(high_command_one_hot) if value == 1),
        "UNKNOWN",
    )

    cleaned = _normalize_generated_line(text)
    if _looks_like_bad_generation(cleaned):
        return (
            "The scene is unclear from the available front-view observation. "
            f"Use the {command_str.lower()} command and ego-motion history to continue cautiously along the route."
        )

    words = cleaned.split()
    if len(words) > 90:
        cleaned = " ".join(words[:90]).rstrip(" ,;")

    return cleaned


def build_cosmos_context_prompt(
    history_trajectory: torch.Tensor,
    high_command_one_hot: torch.Tensor,
    current_velocity: torch.Tensor,
    current_acceleration: torch.Tensor,
) -> str:
    history_str, command_str, vx, vy, ax, ay = _resolve_prompt_values(
        history_trajectory,
        high_command_one_hot,
        current_velocity,
        current_acceleration,
    )
    return (
        "Analyze the autonomous-driving scene and ego-motion context.\n\n"
        "Input context:\n"
        "- Front-view camera image: provided as the image item before this text.\n"
        "- Historical ego motion context, last 4 timesteps from earliest to latest, each as (x, y, heading):\n"
        f"{history_str}\n"
        f"- Active navigation command: [{command_str}]\n"
        f"- Current velocity: ({vx}, {vy}) m/s\n"
        f"- Current acceleration: ({ax}, {ay}) m/s^2"
    )


def build_cosmos_coc_generation_prompt(
    history_trajectory: torch.Tensor,
    high_command_one_hot: torch.Tensor,
    current_velocity: torch.Tensor,
    current_acceleration: torch.Tensor,
) -> str:
    history_str, command_str, vx, vy, ax, ay = _resolve_prompt_values(
        history_trajectory,
        high_command_one_hot,
        current_velocity,
        current_acceleration,
    )
    return (
        "The video depicts the observation from the vehicle's camera.\n"
        "You need to think step by step and identify the objects in the scene "
        "that are critical for safe navigation.\n\n"
        "Additional ego-motion context:\n"
        "- Front-view image is provided.\n"
        "- Ego history (x, y, heading), earliest to latest:\n"
        f"{history_str}\n"
        f"- Command: {command_str}\n"
        f"- Velocity: ({vx}, {vy}) m/s\n"
        f"- Acceleration: ({ax}, {ay}) m/s^2\n"
    )
