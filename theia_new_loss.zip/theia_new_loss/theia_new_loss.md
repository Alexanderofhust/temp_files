将theia里的loss进行了替换，从0.9 cos+0.1 l1,替换成了0.9 dist+0.1 l1。
distloss参考vavae。

改动的文件如下，正常运行训练脚本即可。
- theia/src/theia/models/rvfm.py
- theia/src/theia/scripts/train/train_rvfm.py
- theia/src/theia/utils/logging.py
- theia/src/theia/configs/training/frame_level.yaml