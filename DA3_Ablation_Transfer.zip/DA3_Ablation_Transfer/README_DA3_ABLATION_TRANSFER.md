# DA3 Layer23 / Pre-depth Ablation 迁移说明

这份文件用于把旧版 Theia 代码扩展为支持两组 DA3 教师特征消融：

- `depth-anything/DA3-LARGE-LAYER23`: `[1024, 18, 73]`
- `depth-anything/DA3-LARGE-PREDEPTH-64X256`: `[32, 64, 256]`

不需要新增训练脚本或新的 feature extraction 脚本。复用原来的：

```text
src/theia/scripts/preprocessing/iv_feature_extraction_1024.sh
src/theia/scripts/preprocessing/calc_feature_mean.sh
src/theia/scripts/train/train.sh
```

只需要把下面补丁文件放到项目对应位置，然后按本文修改原脚本里的模型名/target config 参数。

## 1. 放置文件

在对方 Theia 仓库根目录下解压：

```bash
cd $THEIA_ROOT
tar -xzf DA3_Ablation_Transfer.tar.gz --strip-components=1
```

该压缩包只包含以下需要新增或修改的文件：

```text
src/theia/foundation_models/vision_models/depth_anything3.py
src/theia/foundation_models/__init__.py
src/theia/foundation_models/common.py
src/theia/preprocessing/feature_extraction_core/models.py

src/theia/configs/training/target_models/depth_anything3_layer23.yaml
src/theia/configs/training/target_models/depth_anything3_predepth_64x256.yaml
src/theia/configs/training/target_models/sdd_da3_layer23.yaml
src/theia/configs/training/target_models/sdd_da3_predepth_64x256.yaml
```

如果对方代码不是干净原版，前四个 `.py` 文件建议手动 merge；四个 `.yaml` 可以直接新增。

## 2. 提取 Feature Cache

复用原脚本：

```text
src/theia/scripts/preprocessing/iv_feature_extraction_1024.sh
```

修改脚本开头路径：

```bash
dataset=navsim_stitch
numgpus=4
dataset_root=/path/to/theia_navsim_stitch_datasets
output_path=/path/to/theia_navsim_stitch_datasets
```

然后修改 `models`。建议一次只跑一个 DA3 ablation，因为原脚本对 `models` 里的多个模型会后台并行，而 DA3 两个模型都用全部 GPU，并行容易 OOM。

Layer23：

```bash
models=( depth-anything/DA3-LARGE-LAYER23 )
```

Pre-depth：

```bash
models=( depth-anything/DA3-LARGE-PREDEPTH-64X256 )
```

运行：

```bash
cd $THEIA_ROOT/src/theia/scripts/preprocessing
bash iv_feature_extraction_1024.sh
```

输出目录会是：

```text
$dataset_root/navsim_stitch/depth-anything_DA3-LARGE-LAYER23/
$dataset_root/navsim_stitch/depth-anything_DA3-LARGE-PREDEPTH-64X256/
```

## 3. 计算 Mean / Std

可以复用原脚本：

```text
src/theia/scripts/preprocessing/calc_feature_mean.sh
```

但请注意：navsim stitch 训练默认读取 `navsim_stitch_mean_*.npy` 和 `navsim_stitch_var_*.npy`。所以 `calc_feature_mean.sh` 里最好调用：

```bash
python /path/to/theia/src/theia/scripts/preprocessing/calc_feature_mean_1024.py \
  --dataset-path /path/to/theia_navsim_stitch_datasets/navsim_stitch \
  --output-path /path/to/theia_navsim_stitch_datasets
```

如果对方旧代码的 `calc_feature_mean.sh` 仍然调用 `calc_feature_mean.py`，它通常会生成 `navsim_mean_*.npy`，和 navsim stitch 训练需要的文件名前缀不一致，不推荐。

运行：

```bash
cd $THEIA_ROOT/src/theia/scripts/preprocessing
bash calc_feature_mean.sh
```

需要生成：

```text
$dataset_root/navsim_stitch_mean_depth-anything_DA3-LARGE-LAYER23.npy
$dataset_root/navsim_stitch_var_depth-anything_DA3-LARGE-LAYER23.npy
$dataset_root/navsim_stitch_mean_depth-anything_DA3-LARGE-PREDEPTH-64X256.npy
$dataset_root/navsim_stitch_var_depth-anything_DA3-LARGE-PREDEPTH-64X256.npy
```

## 4. 训练

先只做两个DA3单教师的蒸馏，不需要三教师的。蒸馏出来的学生模型，换到Diffusiondrive Theia（不带score，不带latent的那个版本）下训练navsim。

复用原脚本：

```text
src/theia/scripts/train/train.sh
```

单 DA3 teacher 的 Layer23：

```bash
training/target_models=depth_anything3_layer23
logging.notes=navsim_stitch_da3_layer23
```

单 DA3 teacher 的 Pre-depth：

```bash
training/target_models=depth_anything3_predepth_64x256
logging.notes=navsim_stitch_da3_predepth_64x256
```

如果要做三教师，只替换 DA3 分支：

```bash
training/target_models=sdd_da3_layer23
logging.notes=navsim_stitch_sdd_da3_layer23
```

或：

```bash
training/target_models=sdd_da3_predepth_64x256
logging.notes=navsim_stitch_sdd_da3_predepth_64x256
```

建议 `train.sh` 中显式保留/添加这些参数，和之前 navsim stitch 实验对齐：

```bash
training.main_loss=cos_l1 \
dataset.dataset_root=/path/to/theia_navsim_stitch_datasets \
dataset.dataset_ratio=1.0 \
model.backbone.backbone=facebook/deit-small-patch16-224 \
logging.save_ckpt_interval=50000
```

运行：

```bash
cd $THEIA_ROOT/src/theia/scripts/train
bash train.sh
```

## 
