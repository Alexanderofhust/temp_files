# Copyright (c) 2024 Robotics and AI Institute LLC dba RAI Institute. All rights reserved.

from importlib import import_module


_EXPORTS = {
    "get_clip_feature": ".vision_language_models.clip",
    "get_clip_model": ".vision_language_models.clip",
    "get_llava_vision_model": ".vision_language_models.llava",
    "get_llava_visual_feature": ".vision_language_models.llava",
    "get_qwen3_vl_feature": ".vision_language_models.qwen3_vl",
    "get_qwen3_vl_model": ".vision_language_models.qwen3_vl",
    "get_siglip2_feature": ".vision_language_models.siglip2",
    "get_siglip2_model": ".vision_language_models.siglip2",
    "get_cradio_feature": ".vision_models.cradio",
    "get_cradio_model": ".vision_models.cradio",
    "get_deit_feature": ".vision_models.deit",
    "get_deit_model": ".vision_models.deit",
    "get_depth_anything_feature": ".vision_models.depth_anything",
    "get_depth_anything_model": ".vision_models.depth_anything",
    "get_depth_anything3_feature": ".vision_models.depth_anything3",
    "get_depth_anything3_model": ".vision_models.depth_anything3",
    "get_depth_anything3_pre_depth_feature": ".vision_models.depth_anything3",
    "get_dinov2_feature": ".vision_models.dinov2",
    "get_dinov2_model": ".vision_models.dinov2",
    "get_dinov3_feature": ".vision_models.dinov3",
    "get_dinov3_model": ".vision_models.dinov3",
    "get_sam_feature": ".vision_models.sam",
    "get_sam_model": ".vision_models.sam",
    "get_sam3_feature": ".vision_models.sam3",
    "get_sam3_model": ".vision_models.sam3",
    "get_vit_feature": ".vision_models.vit",
    "get_vit_model": ".vision_models.vit",
}

__all__ = sorted(_EXPORTS)


def __getattr__(name: str):
    if name not in _EXPORTS:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

    module = import_module(_EXPORTS[name], __name__)
    value = getattr(module, name)
    globals()[name] = value
    return value
