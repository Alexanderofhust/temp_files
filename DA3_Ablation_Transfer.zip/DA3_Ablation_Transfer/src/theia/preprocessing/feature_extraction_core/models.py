# Copyright (c) 2024 Robotics and AI Institute LLC dba RAI Institute. All rights reserved.

from typing import Any

import torch
import torch.nn as nn
from numpy.typing import NDArray
from torch.nn.functional import interpolate
import theia.foundation_models as foundation_models


def _get_depth_anything3_selected_feature(model_name_lower: str) -> str:
    if (
        "predepth" in model_name_lower
        or "pre-depth" in model_name_lower
        or "pre_depth" in model_name_lower
    ):
        return "predepth_64x256"
    if "layer23" in model_name_lower:
        return "layer23"
    return "layer12"


def get_model(model_name: str, device: int | str | torch.device = "cpu") -> tuple[nn.Module, Any]:
    model_name_lower = model_name.lower()

    if "google/vit" in model_name_lower:
        model, processor = foundation_models.get_vit_model(model_name, device=device)
    elif model_name_lower == "nvidia/c-radiov4-so400m":
        model, processor = foundation_models.get_cradio_model(model_name, device=device)
    elif "google/siglip2" in model_name_lower:
        model, processor = foundation_models.get_siglip2_model(model_name, device=device)
    elif model_name_lower == "qwen/qwen3-vl-8b-instruct":
        model, processor = foundation_models.get_qwen3_vl_model(model_name, device=device)
    elif "facebook/sam3" in model_name_lower:
        model, processor = foundation_models.get_sam3_model(model_name, device=device, with_upscaled=False)
    elif "facebook/sam" in model_name_lower:
        model, processor = foundation_models.get_sam_model(model_name, device=device, with_upscaled=False)
    elif "openai/clip" in model_name_lower:
        model, processor = foundation_models.get_clip_model(model_name, device=device)
    elif "facebook/dinov3" in model_name_lower:
        model, processor = foundation_models.get_dinov3_model(model_name, device=device)
    elif "facebook/dinov2" in model_name_lower:
        model, processor = foundation_models.get_dinov2_model(model_name, device=device)
    elif "llava" in model_name_lower:
        model, processor = foundation_models.get_llava_vision_model(model_name, device=device)
    elif "da3" in model_name_lower or "depth-anything3" in model_name_lower:
        model, processor = foundation_models.get_depth_anything3_model(
            model_name, device=device, selected_feature=_get_depth_anything3_selected_feature(model_name_lower)
        )
    elif "depth-anything" in model_name_lower:
        model, processor = foundation_models.get_depth_anything_model(model_name, device=device, selected_feature="head")
    else:
        raise NotImplementedError(f"{model_name} is not implemented")
    return model, processor


def get_models(
    model_names: list[str], device: int | str | torch.device = "cpu"
) -> tuple[dict[str, nn.Module], dict[str, Any]]:
    models: dict[str, nn.Module] = {}
    processors: dict[str, Any] = {}
    for model_name in model_names:
        model, processor = get_model(model_name, device)
        models[model_name.replace("/", "_")] = model
        processors[model_name.replace("/", "_")] = processor
    return models, processors


def get_feature_outputs(
    model_name: str, model: nn.Module, processor: Any, batch_images: list[NDArray], dtype: torch.dtype = torch.bfloat16
) -> dict[str, dict[str, torch.Tensor]]:
    features: dict[str, dict[str, torch.Tensor]] = {model_name: {}}
    model_name_lower = model_name.lower()

    if "google_vit" in model_name_lower:
        cls_token, feature = foundation_models.get_vit_feature(model, processor, batch_images)
        features[model_name] = {
            "cls_token": cls_token.detach().cpu().to(dtype).contiguous(),
            "embedding": feature.detach().cpu().to(dtype).contiguous()
        }
    elif model_name_lower in {"nvidia_c-radiov4-so400m", "nvidia/c-radiov4-so400m"}:
        cls_token, visual_tokens, pooled_cls_token = foundation_models.get_cradio_feature(model, processor, batch_images)
        features[model_name] = {
            "embedding": visual_tokens.detach().cpu().to(dtype).contiguous(),
            "cls_token": cls_token.detach().cpu().to(dtype).contiguous(),
            "pooled_cls_token": pooled_cls_token.detach().cpu().to(dtype).contiguous(),
        }
    elif model_name_lower in {"qwen_qwen3-vl-8b-instruct", "qwen/qwen3-vl-8b-instruct"}:
        cls_token, visual_tokens, pooled_cls_token = foundation_models.get_qwen3_vl_feature(model, processor, batch_images)
        features[model_name] = {
            "embedding": visual_tokens.detach().cpu().to(dtype).contiguous(),
            "cls_token": cls_token.detach().cpu().to(dtype).contiguous(),
            "pooled_cls_token": pooled_cls_token.detach().cpu().to(dtype).contiguous(),
        }
    elif "facebook_sam3" in model_name_lower:
        feature, upscaled_feature = foundation_models.get_sam3_feature(model, processor, batch_images)
        features[model_name] = {"embedding": feature.detach().cpu().to(dtype).contiguous()}
        features[model_name + "_32"] = {
            "embedding": interpolate(feature, (32, 32)).detach().cpu().to(dtype).contiguous()
        }
        if upscaled_feature:
            features[model_name]["upscaled_embedding"] = upscaled_feature.detach().cpu().to(dtype).contiguous()
    elif "facebook_sam" in model_name_lower:
        feature, upscaled_feature = foundation_models.get_sam_feature(model, processor, batch_images)
        features[model_name] = {"embedding": feature.detach().cpu().to(dtype).contiguous()}
        features[model_name + "_32"] = {
            "embedding": interpolate(feature, (32, 32)).detach().cpu().to(dtype).contiguous()
        }

        if upscaled_feature:
            features[model_name]["upscaled_embedding"] = upscaled_feature.detach().cpu().to(dtype).contiguous()
    elif "openai_clip" in model_name_lower:
        cls_token, visual_tokens, pooled_cls_token = foundation_models.get_clip_feature(model, processor, batch_images)
        features[model_name] = {
            "embedding": visual_tokens.detach().cpu().to(dtype).contiguous(),
            "cls_token": cls_token.detach().cpu().to(dtype).contiguous(),
            "pooled_cls_token": pooled_cls_token.detach().cpu().to(dtype).contiguous(),
        }
    elif "google_siglip2" in model_name_lower:
        cls_token, visual_tokens, pooled_cls_token = foundation_models.get_siglip2_feature(model, processor, batch_images)
        features[model_name] = {
            "embedding": visual_tokens.detach().cpu().to(dtype).contiguous(),
            "cls_token": cls_token.detach().cpu().to(dtype).contiguous(),
            "pooled_cls_token": pooled_cls_token.detach().cpu().to(dtype).contiguous(),
        }
    elif "facebook_dinov3" in model_name_lower:
        cls_token, visual_tokens, pooled_cls_token = foundation_models.get_dinov3_feature(model, processor, batch_images)
        features[model_name] = {
            "embedding": visual_tokens.detach().cpu().to(dtype).contiguous(),
            "cls_token": cls_token.detach().cpu().to(dtype).contiguous(),
            "pooled_cls_token": pooled_cls_token.detach().cpu().to(dtype).contiguous(),
        }
    elif "facebook_dinov2" in model_name_lower:
        cls_token, visual_tokens, pooled_cls_token = foundation_models.get_dinov2_feature(model, processor, batch_images)
        features[model_name] = {
            "embedding": visual_tokens.detach().cpu().to(dtype).contiguous(),
            "cls_token": cls_token.detach().cpu().to(dtype).contiguous(),
            "pooled_cls_token": pooled_cls_token.detach().cpu().to(dtype).contiguous(),
        }
    elif "llava" in model_name_lower:
        feature = foundation_models.get_llava_visual_feature(model, processor, batch_images)
        features[model_name] = {"embedding": feature.detach().cpu().to(dtype).contiguous()}
    elif "da3" in model_name_lower or "depth-anything3" in model_name_lower:
        if getattr(model, "_feature_type", "layer") == "pre_depth":
            feature = foundation_models.get_depth_anything3_pre_depth_feature(
                model,
                processor,
                batch_images,
                target_size=getattr(model, "_pre_depth_target_size", (64, 256)),
            )
        else:
            feature = foundation_models.get_depth_anything3_feature(
                model, processor, batch_images, feature_layer=model._feature_layer
            )
        features[model_name] = {"embedding": feature.detach().cpu().to(dtype).contiguous()}
    elif "depth-anything" in model_name_lower:
        feature = foundation_models.get_depth_anything_feature(model, processor, batch_images)
        features[model_name] = {"embedding": interpolate(feature, (64, 64)).detach().cpu().to(dtype).contiguous()}
    else:
        raise NotImplementedError(f"model {model_name} is not supported")

    return features
